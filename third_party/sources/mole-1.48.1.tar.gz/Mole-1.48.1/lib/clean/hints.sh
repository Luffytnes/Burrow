#!/bin/bash
# Hint notices used by `mo clean` (non-destructive guidance only).

set -euo pipefail

mole_hints_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1090
source "$mole_hints_dir/purge_shared.sh"

# Quick reminder probe for project build artifacts handled by `mo purge`.
# Designed to be very fast: shallow directory checks only, no deep find scans.
# shellcheck disable=SC2329
load_quick_purge_hint_paths() {
    local config_file="$HOME/.config/mole/purge_paths"
    local -a paths=()

    while IFS= read -r line; do
        [[ -n "$line" ]] && paths+=("$line")
    done < <(mole_purge_read_paths_config "$config_file")

    if [[ ${#paths[@]} -eq 0 ]]; then
        paths=("${MOLE_PURGE_DEFAULT_SEARCH_PATHS[@]}")
    fi

    if [[ ${#paths[@]} -gt 0 ]]; then
        printf '%s\n' "${paths[@]}"
    fi
}

# shellcheck disable=SC2329
hint_get_path_size_kb_with_timeout() {
    local path="$1"
    local timeout_seconds="${2:-0.8}"
    local du_tmp
    du_tmp=$(mktemp)

    local du_status=0
    if run_with_timeout "$timeout_seconds" du -skP "$path" > "$du_tmp" 2> /dev/null; then
        du_status=0
    else
        du_status=$?
    fi

    if [[ $du_status -ne 0 ]]; then
        rm -f "$du_tmp"
        return 1
    fi

    local size_kb
    size_kb=$(awk 'NR==1 {print $1; exit}' "$du_tmp")
    rm -f "$du_tmp"

    [[ "$size_kb" =~ ^[0-9]+$ ]] || return 1
    printf '%s\n' "$size_kb"
}

# shellcheck disable=SC2329
hint_collect_child_dirs_with_timeout() {
    local parent="$1"
    local output_file="$2"
    local timeout_seconds="${3:-1}"

    [[ -d "$parent" ]] || return 1
    : > "$output_file" || return 1

    # 1s: shallow directory listing should be near-instant on healthy local
    # paths. Slow/cloud-backed roots are skipped so `mo clean` never appears
    # stuck while rendering this non-destructive hint.
    run_with_timeout "$timeout_seconds" find "$parent" -mindepth 1 -maxdepth 1 -type d -print0 > "$output_file" 2> /dev/null
}

# shellcheck disable=SC2329
hint_extract_launch_agent_program_path() {
    local plist="$1"
    local program=""

    if ! program=$(plutil -extract Program raw "$plist" 2> /dev/null); then
        program=""
    fi
    if [[ -z "$program" ]]; then
        if ! program=$(plutil -extract ProgramArguments.0 raw "$plist" 2> /dev/null); then
            program=""
        fi
    fi

    printf '%s\n' "$program"
}

# shellcheck disable=SC2329
hint_launch_agent_has_mach_services() {
    local plist="$1"
    plutil -extract MachServices raw "$plist" > /dev/null 2>&1
}

# shellcheck disable=SC2329
hint_extract_launch_agent_associated_bundle() {
    local plist="$1"
    local associated=""

    if ! associated=$(plutil -extract AssociatedBundleIdentifiers.0 raw "$plist" 2> /dev/null); then
        associated=""
    fi
    if [[ -z "$associated" ]] || [[ "$associated" == "1" ]]; then
        if ! associated=$(plutil -extract AssociatedBundleIdentifiers raw "$plist" 2> /dev/null); then
            associated=""
        fi
        if [[ "$associated" == "{"* ]] || [[ "$associated" == "["* ]]; then
            associated=""
        fi
    fi

    printf '%s\n' "$associated"
}

# shellcheck disable=SC2329
hint_is_app_scoped_launch_target() {
    local program="$1"

    case "$program" in
        /Applications/Setapp/*.app/* | \
            /Applications/*.app/* | \
            "$HOME"/Applications/*.app/* | \
            "$HOME"/Library/Application\ Support/*.app/* | \
            /Library/Input\ Methods/*.app/* | \
            /Library/PrivilegedHelperTools/*)
            return 0
            ;;
    esac

    return 1
}

# shellcheck disable=SC2329
hint_is_system_binary() {
    local program="$1"

    case "$program" in
        /bin/* | /sbin/* | /usr/bin/* | /usr/sbin/* | /usr/libexec/*)
            return 0
            ;;
    esac

    return 1
}

# shellcheck disable=SC2329
hint_launch_agent_bundle_exists() {
    local bundle_id="$1"

    [[ -z "$bundle_id" ]] && return 1

    # Delegate to the shared resolver so Spotlight misses (e.g. KeePassXC
    # installed via Homebrew) fall back to a direct /Applications scan. See #732.
    bundle_has_installed_app "$bundle_id"
}

# Lowercase and strip to alnum, one line in, one line out. Under LC_ALL=C
# `[:alnum:]` is ASCII, so dropping everything outside a-z0-9 after the
# lowercase pass is the same transform applied line by line.
hint_normalize_app_match_lines() {
    LC_ALL=C tr '[:upper:]' '[:lower:]' | LC_ALL=C tr -cd 'a-z0-9\n'
}

# shellcheck disable=SC2329
hint_collect_installed_gui_app_match_texts() {
    local -a app_roots=(
        "/Applications"
        "/Applications/Setapp"
        "/Applications/Utilities"
        "$HOME/Applications"
        "/Library/Input Methods"
        "$HOME/Library/Input Methods"
        "$HOME/Library/Application Support/Setapp/Applications"
    )

    local app_root app_path app_name info value
    for app_root in "${app_roots[@]}"; do
        [[ -d "$app_root" ]] || continue
        while IFS= read -r -d '' app_path; do
            [[ -n "$app_path" ]] || continue

            app_name="${app_path##*/}"
            app_name="${app_name%.app}"
            printf '%s\n' "$app_name"

            info="$app_path/Contents/Info.plist"
            [[ -f "$info" ]] || continue
            for value in \
                "$(plutil -extract CFBundleIdentifier raw "$info" 2> /dev/null || echo "")" \
                "$(plutil -extract CFBundleName raw "$info" 2> /dev/null || echo "")" \
                "$(plutil -extract CFBundleDisplayName raw "$info" 2> /dev/null || echo "")"; do
                [[ -n "$value" && "$value" != "(null)" ]] && printf '%s\n' "$value"
            done
        done < <(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" find "$app_root" -maxdepth 2 -name "*.app" -print0 2> /dev/null || true)
    done

    local -a cask_roots=(
        "/opt/homebrew/Caskroom"
        "/usr/local/Caskroom"
    )

    local cask_root cask_dir cask_name
    for cask_root in "${cask_roots[@]}"; do
        [[ -d "$cask_root" ]] || continue
        while IFS= read -r -d '' cask_dir; do
            [[ -n "$cask_dir" ]] || continue
            cask_name="${cask_dir##*/}"
            printf '%s\n' "$cask_name"
        done < <(run_with_timeout 1 find "$cask_root" -mindepth 1 -maxdepth 1 -type d -print0 2> /dev/null || true) # 1s: shallow brew cask dir list, see lib/core/timeouts.sh
    done
}

# shellcheck disable=SC2329
hint_dotdir_owned_by_installed_gui_app() {
    local installed_app_texts="$1"
    shift || true
    [[ -n "$installed_app_texts" && $# -gt 0 ]] || return 1

    # Normalize each side once. This used to normalize inside the comparison
    # loop, two tr processes per (app text, candidate) pair, so a machine with
    # ~30 apps spent several hundred processes on a single orphan dotdir.
    # Candidates shorter than 4 chars are dropped, as before, to keep matches
    # like `.ai-old` against `AI.app` from firing (#872).
    local -a needles=()
    local candidate
    while IFS= read -r candidate; do
        [[ ${#candidate} -ge 4 ]] && needles+=("$candidate")
    done < <(printf '%s\n' "$@" | hint_normalize_app_match_lines)
    [[ ${#needles[@]} -gt 0 ]] || return 1

    local value
    while IFS= read -r value; do
        [[ -n "$value" ]] || continue
        for candidate in "${needles[@]}"; do
            if [[ "$value" == *"$candidate"* ]]; then
                return 0
            fi
        done
    done < <(printf '%s\n' "$installed_app_texts" | hint_normalize_app_match_lines)

    return 1
}

# shellcheck disable=SC2329
record_project_artifact_hint() {
    local path="$1"

    PROJECT_ARTIFACT_HINT_COUNT=$((PROJECT_ARTIFACT_HINT_COUNT + 1))

    if [[ ${#PROJECT_ARTIFACT_HINT_EXAMPLES[@]} -lt 2 ]]; then
        PROJECT_ARTIFACT_HINT_EXAMPLES+=("${path/#$HOME/~}")
    fi

    local sample_max=3
    if [[ $PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES -ge $sample_max ]]; then
        PROJECT_ARTIFACT_HINT_ESTIMATE_PARTIAL=true
        return 0
    fi

    local timeout_seconds="0.8"
    local size_kb=""
    if size_kb=$(hint_get_path_size_kb_with_timeout "$path" "$timeout_seconds"); then
        if [[ "$size_kb" =~ ^[0-9]+$ ]]; then
            PROJECT_ARTIFACT_HINT_ESTIMATED_KB=$((PROJECT_ARTIFACT_HINT_ESTIMATED_KB + size_kb))
            PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES=$((PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES + 1))
        else
            PROJECT_ARTIFACT_HINT_ESTIMATE_PARTIAL=true
        fi
    else
        PROJECT_ARTIFACT_HINT_ESTIMATE_PARTIAL=true
    fi

    return 0
}

# shellcheck disable=SC2329
is_quick_purge_project_root() {
    mole_purge_is_project_root "$1"
}

# shellcheck disable=SC2329
probe_project_artifact_hints() {
    PROJECT_ARTIFACT_HINT_DETECTED=false
    PROJECT_ARTIFACT_HINT_COUNT=0
    PROJECT_ARTIFACT_HINT_TRUNCATED=false
    PROJECT_ARTIFACT_HINT_EXAMPLES=()
    PROJECT_ARTIFACT_HINT_ESTIMATED_KB=0
    PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES=0
    PROJECT_ARTIFACT_HINT_ESTIMATE_PARTIAL=false
    PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=false

    local max_projects=200
    local max_projects_per_root=0
    local max_nested_per_project=120
    local max_matches=12
    local list_timeout_seconds=1

    # Wall-clock ceiling for the whole walk. Per-listing finds are already
    # capped at 1s, but with up to max_projects roots the cumulative scan can
    # stretch into minutes on busy machines and look hung (#1053). Checked
    # between iterations so the section degrades gracefully instead of stalling.
    local hint_budget_seconds="${MOLE_TIMEOUT_HINT_SCAN_SEC:-15}"
    [[ "$hint_budget_seconds" =~ ^[0-9]+$ ]] || hint_budget_seconds=15
    local scan_deadline=$((SECONDS + hint_budget_seconds))

    local -a target_names=()
    while IFS= read -r target_name; do
        [[ -n "$target_name" ]] && target_names+=("$target_name")
    done < <(mole_purge_quick_hint_target_names)

    local -a scan_roots=()
    while IFS= read -r path; do
        [[ -n "$path" ]] && scan_roots+=("$path")
    done < <(load_quick_purge_hint_paths)

    [[ ${#scan_roots[@]} -eq 0 ]] && return 0

    # Fairness: avoid one very large root exhausting the entire scan budget.
    if [[ $max_projects_per_root -le 0 ]]; then
        max_projects_per_root=$(((max_projects + ${#scan_roots[@]} - 1) / ${#scan_roots[@]}))
        [[ $max_projects_per_root -lt 25 ]] && max_projects_per_root=25
    fi
    [[ $max_projects_per_root -gt $max_projects ]] && max_projects_per_root=$max_projects

    local scanned_projects=0
    local stop_scan=false
    local root project_dir nested_dir target_name candidate
    local project_dirs_file nested_dirs_file

    for root in "${scan_roots[@]}"; do
        if [[ $SECONDS -ge $scan_deadline ]]; then
            PROJECT_ARTIFACT_HINT_TRUNCATED=true
            PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
            break
        fi
        [[ -d "$root" ]] || continue
        local root_projects_scanned=0

        if is_quick_purge_project_root "$root"; then
            scanned_projects=$((scanned_projects + 1))
            root_projects_scanned=$((root_projects_scanned + 1))
            if [[ $scanned_projects -gt $max_projects ]]; then
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                stop_scan=true
                break
            fi

            for target_name in "${target_names[@]}"; do
                candidate="$root/$target_name"
                if [[ -d "$candidate" ]]; then
                    record_project_artifact_hint "$candidate"
                fi
            done
        fi
        [[ "$stop_scan" == "true" ]] && break

        if [[ $root_projects_scanned -ge $max_projects_per_root ]]; then
            PROJECT_ARTIFACT_HINT_TRUNCATED=true
            continue
        fi

        project_dirs_file=$(mktemp_file "project_artifact_dirs") || {
            PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
            PROJECT_ARTIFACT_HINT_TRUNCATED=true
            continue
        }
        if ! hint_collect_child_dirs_with_timeout "$root" "$project_dirs_file" "$list_timeout_seconds"; then
            PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
            PROJECT_ARTIFACT_HINT_TRUNCATED=true
            rm -f "$project_dirs_file"
            continue
        fi

        while IFS= read -r -d '' project_dir; do
            if [[ $SECONDS -ge $scan_deadline ]]; then
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
                stop_scan=true
                break
            fi
            [[ -d "$project_dir" ]] || continue

            local project_name
            project_name=$(basename "$project_dir")
            [[ "$project_name" == .* ]] && continue

            if [[ $root_projects_scanned -ge $max_projects_per_root ]]; then
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                break
            fi

            scanned_projects=$((scanned_projects + 1))
            root_projects_scanned=$((root_projects_scanned + 1))
            if [[ $scanned_projects -gt $max_projects ]]; then
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                stop_scan=true
                break
            fi

            for target_name in "${target_names[@]}"; do
                candidate="$project_dir/$target_name"
                if [[ -d "$candidate" ]]; then
                    record_project_artifact_hint "$candidate"
                fi
            done
            [[ "$stop_scan" == "true" ]] && break

            if [[ $SECONDS -ge $scan_deadline ]]; then
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
                stop_scan=true
                break
            fi

            local nested_count=0
            nested_dirs_file=$(mktemp_file "project_artifact_nested") || {
                PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                continue
            }
            if ! hint_collect_child_dirs_with_timeout "$project_dir" "$nested_dirs_file" "$list_timeout_seconds"; then
                PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
                PROJECT_ARTIFACT_HINT_TRUNCATED=true
                rm -f "$nested_dirs_file"
                continue
            fi

            while IFS= read -r -d '' nested_dir; do
                if [[ $SECONDS -ge $scan_deadline ]]; then
                    PROJECT_ARTIFACT_HINT_TRUNCATED=true
                    PROJECT_ARTIFACT_HINT_SCAN_SKIPPED=true
                    stop_scan=true
                    break
                fi
                [[ -d "$nested_dir" ]] || continue

                local nested_name
                nested_name=$(basename "$nested_dir")
                [[ "$nested_name" == .* ]] && continue

                case "$nested_name" in
                    node_modules | target | build | dist | DerivedData | Pods)
                        continue
                        ;;
                esac

                nested_count=$((nested_count + 1))
                if [[ $nested_count -gt $max_nested_per_project ]]; then
                    break
                fi

                for target_name in "${target_names[@]}"; do
                    candidate="$nested_dir/$target_name"
                    if [[ -d "$candidate" ]]; then
                        record_project_artifact_hint "$candidate"
                    fi
                done
            done < "$nested_dirs_file"
            rm -f "$nested_dirs_file"

            [[ "$stop_scan" == "true" ]] && break
        done < "$project_dirs_file"
        rm -f "$project_dirs_file"

        [[ "$stop_scan" == "true" ]] && break
    done

    if [[ $PROJECT_ARTIFACT_HINT_COUNT -gt 0 ]]; then
        PROJECT_ARTIFACT_HINT_DETECTED=true
    fi

    # Preserve a compact display hint if candidate count is large, but do not
    # stop scanning early solely because we exceeded this threshold.
    if [[ $PROJECT_ARTIFACT_HINT_COUNT -gt $max_matches ]]; then
        PROJECT_ARTIFACT_HINT_TRUNCATED=true
    fi

    return 0
}

# shellcheck disable=SC2329
show_system_data_hint_notice() {
    local min_gb=2
    local timeout_seconds="0.8"
    local max_hits=3

    local threshold_kb=$((min_gb * 1024 * 1024))
    local -a clue_labels=()
    local -a clue_sizes=()
    local -a clue_paths=()

    local -a labels=(
        "Xcode DerivedData"
        "Xcode Archives"
        "iPhone backups"
        "Simulator data"
        "Docker Desktop data"
        "Mail data"
    )
    local -a paths=(
        "$HOME/Library/Developer/Xcode/DerivedData"
        "$HOME/Library/Developer/Xcode/Archives"
        "$HOME/Library/Application Support/MobileSync/Backup"
        "$HOME/Library/Developer/CoreSimulator/Devices"
        "$HOME/Library/Containers/com.docker.docker/Data"
        "$HOME/Library/Mail"
    )

    local orbstack_data
    for orbstack_data in "$HOME"/Library/Group\ Containers/*dev.orbstack/data; do
        [[ -d "$orbstack_data" ]] || continue
        labels+=("OrbStack data")
        paths+=("$orbstack_data")
        break
    done

    # Several du probes with 0.8s budgets each still add up to seconds.
    start_section_spinner "Checking System Data..."

    local i
    for i in "${!paths[@]}"; do
        local path="${paths[$i]}"
        [[ -d "$path" ]] || continue

        local size_kb=""
        if size_kb=$(hint_get_path_size_kb_with_timeout "$path" "$timeout_seconds"); then
            if [[ "$size_kb" -ge "$threshold_kb" ]]; then
                clue_labels+=("${labels[$i]}")
                clue_sizes+=("$size_kb")
                clue_paths+=("$path")
                if [[ ${#clue_labels[@]} -ge $max_hits ]]; then
                    break
                fi
            fi
        fi
    done

    stop_section_spinner

    if [[ ${#clue_labels[@]} -eq 0 ]]; then
        # Stay silent so an idle System Data clues section collapses.
        debug_log "No common System Data clues detected"
        return 0
    fi

    note_activity

    for i in "${!clue_labels[@]}"; do
        local human_size
        human_size=$(bytes_to_human "$((clue_sizes[i] * 1024))")
        echo -e "  ${YELLOW}${ICON_WARNING}${NC} ${clue_labels[$i]} · ${GREEN}${human_size}${NC} · ${GRAY}$(format_path_link "${clue_paths[$i]}")${NC}"
    done
}

# shellcheck disable=SC2329
show_project_artifact_hint_notice() {
    probe_project_artifact_hints

    if [[ "$PROJECT_ARTIFACT_HINT_DETECTED" != "true" ]]; then
        if [[ "${PROJECT_ARTIFACT_HINT_SCAN_SKIPPED:-false}" == "true" ]]; then
            note_activity
            echo -e "  ${YELLOW}${ICON_WARNING}${NC} Build artifacts · scan skipped · ${GRAY}mo purge${NC}"
        fi
        return 0
    fi

    note_activity

    local hint_count_label="$PROJECT_ARTIFACT_HINT_COUNT"
    [[ "$PROJECT_ARTIFACT_HINT_TRUNCATED" == "true" ]] && hint_count_label="${hint_count_label}+"

    local review_command="mo purge"
    if [[ $PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES -gt 0 && $PROJECT_ARTIFACT_HINT_ESTIMATED_KB -eq 0 ]]; then
        review_command="mo purge --include-empty"
    fi

    # One compact row: "Build artifacts · 15+ dirs, 985.6MB+ · mo purge".
    local detail="${hint_count_label} dirs"
    if [[ $PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES -gt 0 ]]; then
        local estimate_human
        estimate_human=$(bytes_to_human "$((PROJECT_ARTIFACT_HINT_ESTIMATED_KB * 1024))")

        local estimate_is_partial="$PROJECT_ARTIFACT_HINT_ESTIMATE_PARTIAL"
        if [[ "$PROJECT_ARTIFACT_HINT_TRUNCATED" == "true" ]] || [[ $PROJECT_ARTIFACT_HINT_ESTIMATE_SAMPLES -lt $PROJECT_ARTIFACT_HINT_COUNT ]]; then
            estimate_is_partial=true
        fi

        if [[ "$estimate_is_partial" == "true" ]]; then
            detail+=", ${estimate_human}+"
        else
            detail+=", ${estimate_human}"
        fi
    fi

    local partial_note=""
    if [[ "${PROJECT_ARTIFACT_HINT_SCAN_SKIPPED:-false}" == "true" ]]; then
        partial_note=" ${GRAY}(partial scan)${NC}"
    fi

    echo -e "  ${YELLOW}${ICON_WARNING}${NC} Build artifacts · ${GREEN}${detail}${NC} · ${GRAY}${review_command}${NC}${partial_note}"
}

# shellcheck disable=SC2329
show_user_launch_agent_hint_notice() {
    local launch_agents_dir="$HOME/Library/LaunchAgents"
    [[ -d "$launch_agents_dir" ]] || return 0

    local max_hits=3
    local -a labels=()
    local -a reasons=()
    local -a targets=()
    local plist

    # Per-plist target probes add up; keep loading feedback on screen.
    start_section_spinner "Checking login items..."

    while IFS= read -r -d '' plist; do
        local filename
        filename=$(basename "$plist")
        [[ "$filename" == com.apple.* ]] && continue

        local reason=""
        local target=""
        local program=""
        local associated=""

        program=$(hint_extract_launch_agent_program_path "$plist")
        if [[ -z "$program" ]] && hint_launch_agent_has_mach_services "$plist"; then
            continue
        fi
        if [[ -n "$program" ]] && hint_is_system_binary "$program"; then
            continue
        fi
        if [[ "$program" == /* && -f "$program" && -x "$program" ]]; then
            continue
        elif [[ -n "$program" ]] && hint_is_app_scoped_launch_target "$program"; then
            if [[ ! -e "$program" ]]; then
                reason="Missing app/helper target"
                target="${program/#$HOME/~}"
            elif [[ ! -f "$program" || ! -x "$program" ]]; then
                reason="Program target is not executable"
                target="${program/#$HOME/~}"
            fi
        else
            associated=$(hint_extract_launch_agent_associated_bundle "$plist")
            if [[ -n "$associated" ]] && ! hint_launch_agent_bundle_exists "$associated"; then
                reason="Associated app not found"
                target="$associated"
            fi
        fi

        if [[ -n "$reason" ]]; then
            labels+=("$filename")
            reasons+=("$reason")
            targets+=("$target")
            if [[ ${#labels[@]} -ge $max_hits ]]; then
                break
            fi
        fi
    done < <(find "$launch_agents_dir" -maxdepth 1 -name "*.plist" -print0 2> /dev/null)

    stop_section_spinner
    [[ ${#labels[@]} -eq 0 ]] && return 0

    note_activity

    local i
    for i in "${!labels[@]}"; do
        echo -e "  ${YELLOW}${ICON_WARNING}${NC} Stale login item · ${labels[$i]} · ${GRAY}${reasons[$i]}: ${targets[$i]}${NC}"
    done
}

readonly ORPHAN_DOTDIR_KNOWN_SAFE=(
    # Shell
    ".bash_history" ".bash_profile" ".bash_sessions" ".bashrc"
    ".zshrc" ".zsh_history" ".zsh_sessions" ".zprofile" ".zshenv" ".zlogout" ".zcompdump"
    ".profile" ".inputrc" ".hushlogin"
    ".oh-my-zsh" ".zinit" ".zplug" ".antigen" ".p10k.zsh"
    ".config" ".local" ".cache"
    # Security
    ".ssh" ".gnupg" ".gpg" ".pass""word-store"
    # Git
    ".gitconfig" ".gitignore_global" ".git-credentials" ".gitattributes_global"
    # Language tools (Mole handles their caches separately)
    ".pyenv" ".rbenv" ".nvm" ".nodenv" ".goenv" ".jenv"
    ".rustup" ".cargo" ".ghcup" ".stack" ".cabal"
    ".sdkman" ".jabba" ".asdf" ".mise" ".rtx" ".volta" ".fnm"
    ".deno" ".bun"
    # Package managers
    ".npm" ".yarn" ".pnpm" ".bundle" ".gem"
    ".composer" ".nuget" ".pub-cache"
    ".m2" ".gradle" ".sbt" ".ivy2" ".lein"
    ".hex" ".mix" ".opam" ".cpan" ".cpanm"
    ".conda" ".virtualenvs" ".pipx"
    # Cloud / devops
    ".docker" ".kube" ".minikube" ".helm"
    ".aws" ".azure" ".terraform" ".vagrant"
    # Editors / IDEs
    ".vim" ".vimrc" ".viminfo" ".emacs" ".emacs.d" ".doom.d" ".nano" ".nanorc"
    ".vscode" ".cursor" ".atom"
    # AI tools
    ".claude" ".copilot" ".ollama"
    # macOS system
    ".Trash" ".Trashes" ".CFUserTextEncoding" ".DS_Store" ".cups" ".dropbox"
    # Mobile / native dev
    ".android" ".cocoapods" ".fastlane" ".expo" ".react-native" ".swiftpm"
    # Terminal / misc
    ".tmux" ".screen" ".wget-hsts" ".curlrc" ".netrc" ".wgetrc"
    ".putty"
    ".lesshst" ".python_history" ".node_repl_history"
    ".irb_history" ".pry_history"
    ".jupyter" ".ipython" ".matplotlib" ".keras" ".torch"
    ".psql_history" ".mysql_history" ".sqlite_history" ".rediscli_history" ".mongo" ".dbshell"
    # Homebrew / VCS
    ".homebrew" ".hg" ".hgrc" ".svn" ".bazaar"
    # Fly.io / Gemini (Tang uses these)
    ".fly" ".gemini"
)

# Standard locations for installed GUI apps. Overridable from tests.
_MOLE_DOTDIR_OWNER_APP_ROOTS=(
    "/Applications"
    "/Applications/Setapp"
    "$HOME/Applications"
)

# Emit every alnum token found in installed .app filenames + brew casks,
# lowercased, one per line. Caller filters/dedups.
# shellcheck disable=SC2329
_dotdir_owner_collect_tokens() {
    # Collect every name first, then tokenize in one pass. Doing it per name cost
    # a basename plus two tr processes each, so a machine with 30 apps spawned
    # ~90 processes on a path that runs during every clean.
    local root entry name
    local -a names=()
    for root in "${_MOLE_DOTDIR_OWNER_APP_ROOTS[@]}"; do
        [[ -d "$root" ]] || continue
        for entry in "$root"/*.app; do
            [[ -e "$entry" ]] || continue
            name="${entry##*/}"
            names+=("${name%.app}")
        done
    done

    if command -v brew > /dev/null 2>&1; then
        local cask_list=""
        cask_list=$(HOMEBREW_NO_ENV_HINTS=1 run_with_timeout "$MOLE_TIMEOUT_MEDIUM_PROBE_SEC" brew list --cask 2> /dev/null) || true
        if [[ -n "$cask_list" ]]; then
            local cask
            while IFS= read -r cask; do
                [[ -n "$cask" ]] && names+=("$cask")
            done <<< "$cask_list"
        fi
    fi

    # bash 3.2 under nounset rejects "${names[@]}" when the array is empty.
    [[ ${#names[@]} -gt 0 ]] || return 0

    printf '%s\n' "${names[@]}" |
        LC_ALL=C tr '[:upper:]' '[:lower:]' |
        LC_ALL=C tr -cs 'a-z0-9' '\n'
}

# Return 0 if any ≥4-char token from `name` matches a token harvested from
# installed `.app` bundles or Homebrew casks. Cached for 5 minutes. Short
# tokens (<4 chars) on either side are ignored to avoid false matches like
# `.ai-old` vs `AI.app`. See issue #872.
# shellcheck disable=SC2329
dotdir_has_owning_gui_app() {
    local name="$1"
    [[ -z "$name" ]] && return 1
    [[ ${#name} -lt 4 ]] && return 1

    local cache_dir="$HOME/.cache/mole"
    local cache_file="$cache_dir/installed_app_tokens_cache"
    local cache_ttl=300
    local now
    now=$(date +%s)

    local rebuild=1
    if [[ -f "$cache_file" ]]; then
        local mtime
        mtime=$(get_file_mtime "$cache_file" 2> /dev/null || echo 0)
        if [[ -n "$mtime" ]] && [[ $((now - mtime)) -lt $cache_ttl ]]; then
            rebuild=0
        fi
    fi
    if [[ $rebuild -eq 1 ]]; then
        ensure_user_dir "$cache_dir" 2> /dev/null || true
        _dotdir_owner_collect_tokens 2> /dev/null |
            LC_ALL=C awk 'length($0) >= 4' |
            LC_ALL=C sort -u > "$cache_file" 2> /dev/null || return 1
    fi
    [[ -s "$cache_file" ]] || return 1

    local name_lower
    name_lower=$(printf '%s' "$name" | LC_ALL=C tr '[:upper:]' '[:lower:]')
    local tok
    while IFS= read -r tok; do
        [[ -z "$tok" ]] && continue
        [[ ${#tok} -ge 4 ]] || continue
        if LC_ALL=C grep -Fxq "$tok" "$cache_file" 2> /dev/null; then
            return 0
        fi
    done < <(printf '%s\n' "$name_lower" | LC_ALL=C tr -cs 'a-z0-9' '\n')

    return 1
}

# Collect Claude Code plugin name tokens (the segment before '@' in a
# "plugin@marketplace" identifier) from the user's plugin config. Plugins own
# state directories such as ~/.cc-safety-net without installing a matching PATH
# binary or GUI app, so their dotdirs must not be flagged as orphans.
hint_collect_claude_plugin_tokens() {
    local settings="$HOME/.claude/settings.json"
    local installed="$HOME/.claude/plugins/installed_plugins.json"
    # `|| true` keeps a no-match grep (the common case: Claude Code installed
    # but no plugins) from aborting under `set -euo pipefail`.
    {
        if [[ -f "$settings" ]]; then
            plutil -extract enabledPlugins json -o - "$settings" 2> /dev/null |
                LC_ALL=C grep -oE '"[A-Za-z0-9._-]+@[A-Za-z0-9._-]+"' || true
        fi
        if [[ -f "$installed" ]]; then
            LC_ALL=C grep -oE '"[A-Za-z0-9._-]+@[A-Za-z0-9._-]+"' "$installed" 2> /dev/null || true
        fi
    } | sed -E 's/^"//; s/@.*$//' | LC_ALL=C sort -u
}

# Return 0 when a dotdir name embeds an enabled Claude Code plugin token.
# e.g. dotdir "cc-safety-net" embeds plugin token "safety-net".
hint_dotdir_owned_by_claude_plugin() {
    local dotdir_name="$1"
    local tokens="$2"
    [[ -n "$tokens" ]] || return 1
    local token
    while IFS= read -r token; do
        [[ ${#token} -ge 4 ]] || continue
        if [[ "$dotdir_name" == *"$token"* ]]; then
            return 0
        fi
    done <<< "$tokens"
    return 1
}

# Detect ~/.<dir> directories that may belong to uninstalled CLI tools.
# shellcheck disable=SC2329
show_orphan_dotdir_hint_notice() {
    local max_hits=5
    local age_days="${MOLE_DOTDIR_ORPHAN_AGE_DAYS:-60}"
    local now
    now=$(date +%s)

    local -a labels=()
    local installed_gui_app_texts=""
    local installed_gui_app_texts_loaded=false
    local claude_plugin_tokens=""
    local claude_plugin_tokens_loaded=false

    # Per-dotdir du probes take seconds in total; without a spinner the
    # section looks hung.
    start_section_spinner "Checking orphan dotfiles..."

    while IFS= read -r dotdir; do
        [[ -d "$dotdir" ]] || continue
        local basename
        basename=$(basename "$dotdir")

        local is_safe=false
        local safe_name
        for safe_name in "${ORPHAN_DOTDIR_KNOWN_SAFE[@]}"; do
            if [[ "$basename" == "$safe_name" ]]; then
                is_safe=true
                break
            fi
        done
        [[ "$is_safe" == "true" ]] && continue

        if declare -f is_path_whitelisted > /dev/null && is_path_whitelisted "$dotdir"; then
            continue
        fi

        local mtime
        mtime=$(get_file_mtime "$dotdir" 2> /dev/null) || continue
        local age_d=$(((now - mtime) / 86400))
        [[ $age_d -lt $age_days ]] && continue

        local name="${basename#.}"
        local -a candidates=("$name")
        local dehyphen="${name//-/_}"
        [[ "$dehyphen" != "$name" ]] && candidates+=("$dehyphen")
        local stripped="${name//-/}"
        [[ "$stripped" != "$name" && "$stripped" != "$dehyphen" ]] && candidates+=("$stripped")
        local no_suffix="${name%-cli}"
        [[ "$no_suffix" != "$name" ]] && candidates+=("$no_suffix")
        no_suffix="${name%-temp}"
        [[ "$no_suffix" != "$name" ]] && candidates+=("$no_suffix")
        no_suffix="${name%-data}"
        [[ "$no_suffix" != "$name" ]] && candidates+=("$no_suffix")

        local has_binary=false
        local c
        for c in "${candidates[@]}"; do
            if command -v "$c" > /dev/null 2>&1; then
                has_binary=true
                break
            fi
        done
        [[ "$has_binary" == "true" ]] && continue

        if [[ "$claude_plugin_tokens_loaded" != "true" ]]; then
            claude_plugin_tokens=$(hint_collect_claude_plugin_tokens)
            claude_plugin_tokens_loaded=true
        fi
        if hint_dotdir_owned_by_claude_plugin "$name" "$claude_plugin_tokens"; then
            continue
        fi

        if [[ "$installed_gui_app_texts_loaded" != "true" ]]; then
            installed_gui_app_texts=$(hint_collect_installed_gui_app_match_texts)
            installed_gui_app_texts_loaded=true
        fi
        if hint_dotdir_owned_by_installed_gui_app "$installed_gui_app_texts" "${candidates[@]}"; then
            continue
        fi

        if [[ -d "$HOME/Library/LaunchAgents" ]]; then
            if run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" grep -rlq "$basename" "$HOME/Library/LaunchAgents/" 2> /dev/null; then
                continue
            fi
        fi

        if dotdir_has_owning_gui_app "$name"; then
            continue
        fi

        local size_note=""
        local size_kb
        if size_kb=$(hint_get_path_size_kb_with_timeout "$dotdir" 0.8); then
            # Empty dotdirs reclaim nothing, so reviewing them is not worth a
            # row. A failed probe (timeout) means the dir is big: keep it.
            if [[ "$size_kb" -eq 0 ]]; then
                continue
            fi
            size_note=" $(bytes_to_human $((size_kb * 1024)))"
        fi

        # shellcheck disable=SC2088
        labels+=("~/${basename}${size_note}")

        if [[ ${#labels[@]} -ge $max_hits ]]; then
            break
        fi
    done < <(run_with_timeout "$MOLE_TIMEOUT_SHORT_QUERY_SEC" find "$HOME" -maxdepth 1 -mindepth 1 -type d -name '.*' 2> /dev/null | LC_ALL=C sort)

    stop_section_spinner
    [[ ${#labels[@]} -eq 0 ]] && return 0

    note_activity

    # One compact row for the whole finding: label first, entries as detail.
    local joined="" entry
    for entry in "${labels[@]}"; do
        joined+="${joined:+ · }${entry}"
    done
    echo -e "  ${YELLOW}${ICON_WARNING}${NC} Orphan dotfiles · ${GRAY}${joined}${NC}"
}
