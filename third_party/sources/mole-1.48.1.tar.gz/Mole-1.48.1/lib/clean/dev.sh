#!/bin/bash
# Developer Tools Cleanup Module
set -euo pipefail

# Tool cache helper (respects DRY_RUN and whitelist).
# Args:
#   $1 = description (display name)
#   $2 = cache path to check against whitelist (empty string to skip check)
#   $3+ = command to run
clean_tool_cache() {
    local description="$1"
    local cache_path="$2"
    shift 2

    if [[ -n "$cache_path" ]] && is_path_whitelisted "$cache_path"; then
        if [[ "$DRY_RUN" == "true" ]]; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} $description · would skip (whitelist)"
            note_activity
        else
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} $description · skipped (whitelist)"
            note_activity
        fi
        return 0
    fi

    if [[ "$DRY_RUN" != "true" ]]; then
        local command_succeeded=false
        if [[ -t 1 ]]; then
            start_section_spinner "Cleaning $description..."
        fi
        if "$@" > /dev/null 2>&1; then
            command_succeeded=true
        fi
        if [[ -t 1 ]]; then
            stop_section_spinner
        fi
        if [[ "$command_succeeded" == "true" ]]; then
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} $description"
            note_activity
        fi
    else
        echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} $description · would clean"
        note_activity
    fi
    return 0
}

clean_corepack_cache() {
    local corepack_home="${COREPACK_HOME:-$HOME/.cache/node/corepack}"
    [[ -n "$corepack_home" && "$corepack_home" == /* ]] || return 0
    case "$corepack_home" in
        / | "$HOME" | "$HOME/" | "$HOME/Library" | "$HOME/Library/")
            debug_log "Skipping unsafe Corepack cache path: $corepack_home"
            return 0
            ;;
    esac
    # COREPACK_ENABLE_DOWNLOAD_PROMPT=0 mirrors the pnpm path above: without it
    # corepack can stop on an interactive "download? [Y/n]" prompt. Because the
    # call is wrapped with stdout/stderr to /dev/null, that prompt is invisible
    # and the command looks frozen until the timeout fires (seen on a Node setup
    # where corepack is installed; machines without corepack take the else
    # branch and never hit this).
    if command -v corepack > /dev/null 2>&1 && COREPACK_ENABLE_DOWNLOAD_PROMPT=0 run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" corepack --version > /dev/null 2>&1; then
        COREPACK_ENABLE_DOWNLOAD_PROMPT=0 clean_tool_cache "Corepack cache" "$corepack_home" run_with_timeout "$MOLE_TIMEOUT_PKG_CLEANUP_SEC" corepack cache clean
    else
        safe_clean "$corepack_home"/* "Corepack cache"
    fi
}

clean_uv_cache() {
    local uv_cache_path="$HOME/.cache/uv"
    if command -v uv > /dev/null 2>&1 && run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" uv --version > /dev/null 2>&1; then
        local detected_cache
        detected_cache=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" uv cache dir 2> /dev/null || true)
        if [[ -n "$detected_cache" && "$detected_cache" == /* ]]; then
            uv_cache_path="$detected_cache"
        fi
        clean_tool_cache "uv cache" "$uv_cache_path" run_with_timeout "$MOLE_TIMEOUT_PKG_CLEANUP_SEC" uv cache prune
    else
        safe_clean "$uv_cache_path"/* "uv cache"
    fi
}

conda_cache_whitelisted() {
    local root
    for root in "$@"; do
        [[ -n "$root" ]] || continue
        if is_path_whitelisted "$root" 2> /dev/null || is_path_whitelisted "$root/.mole-cache-guard" 2> /dev/null; then
            return 0
        fi
    done
    return 1
}

clean_conda_metadata_caches() {
    local -a conda_pkg_roots=(
        "$HOME/.conda/pkgs"
        "$HOME/anaconda3/pkgs"
        "$HOME/miniconda3/pkgs"
        "$HOME/miniforge3/pkgs"
        "$HOME/mambaforge/pkgs"
    )
    if conda_cache_whitelisted "${conda_pkg_roots[@]}"; then
        if [[ "$DRY_RUN" == "true" ]]; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} conda index/tarball/log caches · would skip (whitelist)"
        else
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} conda index/tarball/log caches · skipped (whitelist)"
            note_activity
        fi
        return 0
    fi

    local conda_cache_hint="$HOME/.conda/pkgs"
    if command -v conda > /dev/null 2>&1 && run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" conda --version > /dev/null 2>&1; then
        clean_tool_cache "conda index/tarball/log caches" "$conda_cache_hint" \
            run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" conda clean --yes --index-cache --tarballs --logfiles
        note_activity
        return 0
    fi

    local root
    for root in "${conda_pkg_roots[@]}"; do
        [[ -d "$root" ]] || continue
        debug_log "Conda package cache present but conda is unavailable, leaving for manual review: $root"
    done
}

gradle_daemon_running() {
    pgrep -f "org.gradle.launcher.daemon" > /dev/null 2>&1 && return 0
    pgrep -f "GradleDaemon" > /dev/null 2>&1 && return 0
    return 1
}

# npm/pnpm/yarn/bun caches.
clean_dev_npm() {
    local npm_default_cache="$HOME/.npm"
    local npm_cache_path="$npm_default_cache"

    if command -v npm > /dev/null 2>&1; then
        start_section_spinner "Checking npm cache path..."
        npm_cache_path=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" npm config get cache 2> /dev/null) || npm_cache_path=""
        stop_section_spinner

        if [[ -z "$npm_cache_path" || "$npm_cache_path" != /* ]]; then
            npm_cache_path="$npm_default_cache"
        fi

        clean_tool_cache "npm cache" "$npm_cache_path" npm cache clean --force
        note_activity
    fi

    # These residual directories are not removed by `npm cache clean --force`
    local -a npm_residual_dirs=("_cacache" "_npx" "_logs" "_prebuilds")
    local -a npm_descriptions=("npm cache directory" "npm npx cache" "npm logs" "npm prebuilds")

    # Clean default npm cache path
    local i
    for i in "${!npm_residual_dirs[@]}"; do
        safe_clean "$npm_default_cache/${npm_residual_dirs[$i]}"/* "${npm_descriptions[$i]}"
    done

    # Normalize paths for comparison (remove trailing slash + resolve symlinked dirs)
    local npm_cache_path_normalized="${npm_cache_path%/}"
    local npm_default_cache_normalized="${npm_default_cache%/}"
    if [[ -d "$npm_cache_path_normalized" ]]; then
        npm_cache_path_normalized=$(cd "$npm_cache_path_normalized" 2> /dev/null && pwd -P) || npm_cache_path_normalized="${npm_cache_path%/}"
    fi
    if [[ -d "$npm_default_cache_normalized" ]]; then
        npm_default_cache_normalized=$(cd "$npm_default_cache_normalized" 2> /dev/null && pwd -P) || npm_default_cache_normalized="${npm_default_cache%/}"
    fi

    # Clean custom npm cache path (if different from default)
    if [[ "$npm_cache_path_normalized" != "$npm_default_cache_normalized" ]]; then
        for i in "${!npm_residual_dirs[@]}"; do
            safe_clean "$npm_cache_path/${npm_residual_dirs[$i]}"/* "${npm_descriptions[$i]} (custom path)"
        done
    fi

    # Clean pnpm store cache
    local pnpm_default_store=~/Library/pnpm/store
    # Check if pnpm is actually usable (not just Corepack shim)
    if command -v pnpm > /dev/null 2>&1 && COREPACK_ENABLE_DOWNLOAD_PROMPT=0 pnpm --version > /dev/null 2>&1; then
        local pnpm_store_path
        start_section_spinner "Checking store path..."
        pnpm_store_path=$(COREPACK_ENABLE_DOWNLOAD_PROMPT=0 run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" pnpm store path 2> /dev/null) || pnpm_store_path=""
        stop_section_spinner

        local pnpm_cache_check="$pnpm_default_store"
        if [[ -n "$pnpm_store_path" && "$pnpm_store_path" == /* ]]; then
            pnpm_cache_check="$pnpm_store_path"
        fi
        COREPACK_ENABLE_DOWNLOAD_PROMPT=0 clean_tool_cache "pnpm cache" "$pnpm_cache_check" run_with_timeout "$MOLE_TIMEOUT_PKG_CLEANUP_SEC" pnpm store prune
    else
        debug_log "pnpm is unavailable, leaving global pnpm store for manual review: $pnpm_default_store"
    fi
    clean_corepack_cache
    local bun_default_cache="$HOME/.bun/install/cache"
    local bun_cache_path="$bun_default_cache"
    local bun_cache_cleaned=false
    local bun_dry_run="${DRY_RUN:-false}"
    if command -v bun > /dev/null 2>&1 && bun --version > /dev/null 2>&1; then
        if [[ -t 1 ]]; then start_section_spinner "Checking bun cache path..."; fi
        bun_cache_path=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" bun pm cache 2> /dev/null) || bun_cache_path=""
        if [[ -t 1 ]]; then stop_section_spinner; fi

        if [[ -z "$bun_cache_path" || "$bun_cache_path" != /* ]]; then
            bun_cache_path="$bun_default_cache"
        fi

        local bun_protected=false
        is_path_whitelisted "$bun_cache_path" && bun_protected=true

        if [[ "$bun_protected" == "true" ]]; then
            if [[ "$bun_dry_run" == "true" ]]; then
                echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} bun cache · would skip (whitelist)"
            else
                echo -e "  ${GREEN}${ICON_SUCCESS}${NC} bun cache · skipped (whitelist)"
                note_activity
            fi
            bun_cache_cleaned=true
        elif [[ "$bun_dry_run" != "true" ]]; then
            if [[ -t 1 ]]; then
                start_section_spinner "Cleaning bun cache..."
            fi
            if run_with_timeout "$MOLE_TIMEOUT_PKG_LIST_SEC" bun pm cache rm > /dev/null 2>&1; then
                bun_cache_cleaned=true
            fi
            if [[ -t 1 ]]; then
                stop_section_spinner
            fi
            if [[ "$bun_cache_cleaned" == "true" ]]; then
                echo -e "  ${GREEN}${ICON_SUCCESS}${NC} bun cache"
                note_activity
            fi
        else
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} bun cache · would clean"
            note_activity
            bun_cache_cleaned=true
        fi

        local bun_cache_path_normalized="${bun_cache_path%/}"
        local bun_default_cache_normalized="${bun_default_cache%/}"
        if [[ -d "$bun_cache_path_normalized" ]]; then
            bun_cache_path_normalized=$(cd "$bun_cache_path_normalized" 2> /dev/null && pwd -P) || bun_cache_path_normalized="${bun_cache_path%/}"
        fi
        if [[ -d "$bun_default_cache_normalized" ]]; then
            bun_default_cache_normalized=$(cd "$bun_default_cache_normalized" 2> /dev/null && pwd -P) || bun_default_cache_normalized="${bun_default_cache%/}"
        fi

        if [[ "$bun_cache_path_normalized" != "$bun_default_cache_normalized" ]]; then
            safe_clean "$bun_default_cache"/* "Orphaned bun cache"
        fi

        # If bun pm cache rm fails, fall back to filesystem cleanup to avoid no-op.
        if [[ "$bun_cache_cleaned" != "true" ]]; then
            safe_clean "$bun_cache_path"/* "Bun cache"
        fi
    else
        safe_clean "$bun_default_cache"/* "Bun cache"
    fi

    note_activity
    safe_clean ~/.tnpm/_cacache/* "tnpm cache directory"
    safe_clean ~/.tnpm/_logs/* "tnpm logs"
    safe_clean ~/.yarn/cache/* "Yarn cache"
    safe_clean ~/Library/Caches/Yarn/* "Yarn v1 cache"
}
# Python/pip ecosystem caches.
clean_dev_python() {
    # Check pip3 is functional (not just macOS stub that triggers CLT install dialog)
    if command -v pip3 > /dev/null 2>&1 && pip3 --version > /dev/null 2>&1; then
        local pip_cache_path
        pip_cache_path=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" pip3 cache dir 2> /dev/null) || pip_cache_path=""
        if [[ -z "$pip_cache_path" || "$pip_cache_path" != /* ]]; then
            pip_cache_path="$HOME/Library/Caches/pip"
        fi
        clean_tool_cache "pip cache" "$pip_cache_path" bash -c 'pip3 cache purge > /dev/null 2>&1 || true'
        note_activity
    fi
    safe_clean ~/.pyenv/cache/* "pyenv cache"
    safe_clean ~/.cache/poetry/* "Poetry cache"
    clean_uv_cache
    safe_clean ~/.cache/ruff/* "Ruff cache"
    safe_clean ~/.cache/mypy/* "MyPy cache"
    safe_clean ~/.pytest_cache/* "Pytest cache"
    safe_clean ~/.jupyter/runtime/* "Jupyter runtime cache"
    safe_clean ~/.cache/huggingface/* "Hugging Face cache"
    safe_clean ~/.cache/torch/* "PyTorch cache"
    safe_clean ~/.cache/tensorflow/* "TensorFlow cache"
    clean_conda_metadata_caches
    safe_clean ~/.cache/wandb/* "Weights & Biases cache"
}
# Go build/module caches.
clean_dev_go() {
    command -v go > /dev/null 2>&1 || return 0

    local go_build_cache go_mod_cache
    go_build_cache=$(go env GOCACHE 2> /dev/null || echo "$HOME/Library/Caches/go-build")
    go_mod_cache=$(go env GOMODCACHE 2> /dev/null || echo "$HOME/go/pkg/mod")

    local build_protected=false mod_protected=false
    is_path_whitelisted "$go_build_cache" && build_protected=true
    is_path_whitelisted "$go_mod_cache" && mod_protected=true

    if [[ "$build_protected" == "true" && "$mod_protected" == "true" ]]; then
        if [[ "$DRY_RUN" == "true" ]]; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Go cache · would skip (whitelist)"
        else
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Go cache · skipped (whitelist)"
            note_activity
        fi
        return 0
    fi

    if [[ "$build_protected" != "true" && "$mod_protected" != "true" ]]; then
        clean_tool_cache "Go cache" "" bash -c 'go clean -modcache > /dev/null 2>&1 || true; go clean -cache > /dev/null 2>&1 || true'
    elif [[ "$build_protected" == "true" ]]; then
        clean_tool_cache "Go module cache" "" bash -c 'go clean -modcache > /dev/null 2>&1 || true'
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Go build cache · skipped (whitelist)"
        note_activity
    else
        clean_tool_cache "Go build cache" "" bash -c 'go clean -cache > /dev/null 2>&1 || true'
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Go module cache · skipped (whitelist)"
    fi
    note_activity
}

get_mise_cache_path() {
    if [[ -n "${MISE_CACHE_DIR:-}" && "${MISE_CACHE_DIR}" == /* ]]; then
        echo "$MISE_CACHE_DIR"
        return 0
    fi

    if command -v mise > /dev/null 2>&1; then
        local mise_cache_path
        mise_cache_path=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" mise cache path 2> /dev/null || echo "")
        if [[ -n "$mise_cache_path" && "$mise_cache_path" == /* ]]; then
            echo "$mise_cache_path"
            return 0
        fi
    fi

    echo "$HOME/Library/Caches/mise"
}

clean_dev_mise() {
    local mise_cache_path
    mise_cache_path=$(get_mise_cache_path)

    if command -v mise > /dev/null 2>&1; then
        if [[ "${DRY_RUN:-false}" != "true" ]]; then
            clean_tool_cache "mise cache" "$mise_cache_path" bash -c 'mise cache clear > /dev/null 2>&1 || true'
            note_activity
        elif is_path_whitelisted "$mise_cache_path"; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} mise cache · would skip (whitelist)"
            note_activity
        else
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} mise cache · would clean"
            note_activity
        fi
    fi

    safe_clean "$mise_cache_path"/* "mise cache"
}
# Rust/cargo caches.
clean_dev_rust() {
    safe_clean ~/.cargo/registry/cache/* "Rust cargo cache"
    safe_clean ~/.cargo/git/* "Cargo git cache"
    safe_clean ~/.rustup/downloads/* "Rust downloads cache"
}
# Ruby/gem ecosystem caches (not installed versions).
clean_dev_ruby() {
    safe_clean ~/.rbenv/cache/* "rbenv download cache"
    safe_clean ~/.gem/specs/* "gem spec cache"
    safe_clean ~/.gem/ruby/*/cache/*.gem "gem package cache"
    safe_clean ~/.bundle/cache/* "Ruby Bundler cache"
}
# Perl ecosystem caches (not installed modules).
clean_dev_perl() {
    safe_clean ~/.cpan/build/* "CPAN build artifacts"
    safe_clean ~/.cpan/sources/* "CPAN source cache"
}

# Helper: Check for multiple versions in a directory.
# Args: $1=directory, $2=tool_name, $3=list_command, $4=remove_command
check_multiple_versions() {
    local dir="$1"
    local tool_name="$2"
    local list_cmd="${3:-}"
    local remove_cmd="${4:-}"

    if [[ ! -d "$dir" ]]; then
        return 0
    fi

    local count
    count=$(find "$dir" -mindepth 1 -maxdepth 1 -type d 2> /dev/null | wc -l | tr -d ' ')

    if [[ "$count" -gt 1 ]]; then
        note_activity
        local hint=""
        if [[ -n "$list_cmd" ]]; then
            hint=" ${GRAY}(${list_cmd})${NC}"
        fi
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} ${tool_name} · ${count} found${hint}"
    fi
}

# Check for multiple Rust toolchains.
check_rust_toolchains() {
    command -v rustup > /dev/null 2>&1 || return 0

    check_multiple_versions \
        "$HOME/.rustup/toolchains" \
        "Rust toolchains" \
        "rustup toolchain list"
}
# Docker caches (guarded by daemon check).
find_orbstack_data_dir() {
    local candidate
    for candidate in "$HOME"/Library/Group\ Containers/*dev.orbstack/data; do
        [[ -d "$candidate" ]] || continue
        printf '%s\n' "$candidate"
        return 0
    done
    return 1
}

clean_dev_docker() {
    if command -v docker > /dev/null 2>&1; then
        note_activity
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Docker unused data · skipped (review: docker system df)"
        debug_log "Docker daemon-managed cleanup skipped by default"
    fi

    local orb_data=""
    orb_data=$(find_orbstack_data_dir 2> /dev/null || true)
    if command -v orb > /dev/null 2>&1 || command -v orbctl > /dev/null 2>&1 || [[ -d "$HOME/.orbstack" || -n "$orb_data" ]]; then
        local orb_size=0
        if [[ -n "$orb_data" ]]; then
            orb_size=$(get_path_size_kb "$orb_data" 2> /dev/null || echo 0)
            [[ "$orb_size" =~ ^[0-9]+$ ]] || orb_size=0
        fi
        note_activity
        echo -e "  ${GRAY}${ICON_WARNING}${NC} OrbStack container data · skipped ($(bytes_to_human $((orb_size * 1024))), review: docker system df)"
        debug_log "OrbStack daemon-managed data left for manual prune ($orb_size KB)"
    fi
    safe_clean ~/.docker/buildx/cache/* "Docker BuildX cache"
}
# Nix garbage collection.
clean_dev_nix() {
    if command -v nix-collect-garbage > /dev/null 2>&1; then
        if [[ "$DRY_RUN" != "true" ]]; then
            clean_tool_cache "Nix garbage collection" "/nix/store" nix-collect-garbage --delete-older-than 30d
        elif is_path_whitelisted "/nix/store"; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Nix garbage collection · would skip (whitelist)"
            note_activity
        else
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Nix garbage collection · would clean"
        fi
        note_activity
    fi
}
# Cloud CLI caches.
clean_dev_cloud() {
    safe_clean ~/.kube/cache/* "Kubernetes cache"
    safe_clean ~/.local/share/containers/storage/tmp/* "Container storage temp"
    safe_clean ~/.aws/cli/cache/* "AWS CLI cache"
    safe_clean ~/.config/gcloud/logs/* "Google Cloud logs"
    safe_clean ~/.azure/logs/* "Azure CLI logs"
}
# Frontend build caches.
clean_dev_frontend() {
    safe_clean ~/.cache/typescript/* "TypeScript cache"
    safe_clean ~/.cache/electron/* "Electron cache"
    safe_clean ~/.cache/node-gyp/* "node-gyp cache"
    safe_clean ~/.node-gyp/* "node-gyp build cache"
    safe_clean ~/.turbo/cache/* "Turbo cache"
    safe_clean ~/.vite/cache/* "Vite cache"
    safe_clean ~/.cache/vite/* "Vite global cache"
    safe_clean ~/.cache/webpack/* "Webpack cache"
    safe_clean ~/.parcel-cache/* "Parcel cache"
    safe_clean ~/.cache/eslint/* "ESLint cache"
    safe_clean ~/.cache/prettier/* "Prettier cache"
}
# Check for multiple Android NDK versions.
check_android_ndk() {
    check_multiple_versions \
        "$HOME/Library/Android/sdk/ndk" \
        "Android NDK versions" \
        "Android Studio → SDK Manager"
}

clean_xcode_documentation_cache() {
    local doc_cache_root="${MOLE_XCODE_DOCUMENTATION_CACHE_DIR:-/Library/Developer/Xcode/DocumentationCache}"
    [[ -d "$doc_cache_root" ]] || return 0

    if pgrep -x "Xcode" > /dev/null 2>&1; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode documentation cache · skipped (Xcode running)"
        note_activity
        return 0
    fi

    local -a index_entries=()
    while IFS= read -r -d '' entry; do
        index_entries+=("$entry")
    done < <(command find "$doc_cache_root" -mindepth 1 -maxdepth 1 \( -name "DeveloperDocumentation.index" -o -name "DeveloperDocumentation*.index" \) -print0 2> /dev/null)

    if [[ ${#index_entries[@]} -le 1 ]]; then
        return 0
    fi

    local -a sorted_entries=()
    while IFS= read -r line; do
        sorted_entries+=("${line#* }")
    done < <(
        for entry in "${index_entries[@]}"; do
            local mtime
            mtime=$(stat -f%m "$entry" 2> /dev/null || echo "0")
            printf '%s %s\n' "$mtime" "$entry"
        done | sort -rn
    )

    local -a stale_entries=()
    local idx=0
    local entry
    for entry in "${sorted_entries[@]}"; do
        if [[ $idx -eq 0 ]]; then
            idx=$((idx + 1))
            continue
        fi
        stale_entries+=("$entry")
        idx=$((idx + 1))
    done

    if [[ ${#stale_entries[@]} -eq 0 ]]; then
        return 0
    fi

    if [[ "${DRY_RUN:-false}" == "true" ]]; then
        safe_clean "${stale_entries[@]}" "Xcode documentation cache (old indexes)"
        note_activity
        return 0
    fi

    if ! has_sudo_session; then
        if ! ensure_sudo_session "Cleaning Xcode documentation cache requires admin access"; then
            echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode documentation cache · skipped (sudo denied)"
            note_activity
            return 0
        fi
    fi

    local removed_count=0
    local skipped_count=0
    local stale_entry
    for stale_entry in "${stale_entries[@]}"; do
        if should_protect_path "$stale_entry" || is_path_whitelisted "$stale_entry"; then
            skipped_count=$((skipped_count + 1))
            continue
        fi
        if safe_sudo_remove "$stale_entry"; then
            removed_count=$((removed_count + 1))
        fi
    done

    if [[ $removed_count -gt 0 ]]; then
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode documentation cache · removed ${removed_count} old indexes"
        if [[ $skipped_count -gt 0 ]]; then
            echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode documentation cache · skipped ${skipped_count} protected items"
        fi
        note_activity
    elif [[ $skipped_count -gt 0 ]]; then
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode documentation cache · already clean"
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode documentation cache · skipped ${skipped_count} protected items"
        note_activity
    else
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode documentation cache · no items removed"
        note_activity
    fi
}

_coresimulator_cache_process_running() {
    pgrep -x "Xcode" > /dev/null 2>&1 ||
        pgrep -x "Simulator" > /dev/null 2>&1 ||
        pgrep -x "CoreSimulatorService" > /dev/null 2>&1 ||
        pgrep -x "simdiskimaged" > /dev/null 2>&1 ||
        pgrep -f "com.apple.CoreSimulator" > /dev/null 2>&1
}

_xcode_xctest_devices_process_running() {
    _coresimulator_cache_process_running ||
        pgrep -x "xcodebuild" > /dev/null 2>&1 ||
        pgrep -x "xctest" > /dev/null 2>&1 ||
        pgrep -x "XCTRunner" > /dev/null 2>&1 ||
        pgrep -f "com.apple.dt.XCTest" > /dev/null 2>&1 ||
        pgrep -f "XCTest" > /dev/null 2>&1
}

clean_xcode_xctest_devices() {
    local xctest_devices_dir="${MOLE_XCODE_XCTEST_DEVICES_DIR:-$HOME/Library/Developer/XCTestDevices}"
    [[ -d "$xctest_devices_dir" ]] || return 0

    if _xcode_xctest_devices_process_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode XCTestDevices · skipped (Xcode or XCTest running)"
        note_activity
        return 0
    fi

    safe_clean "$xctest_devices_dir" "Xcode XCTestDevices test data"
}

clean_xcode_system_coresimulator_caches() {
    local cache_root="${MOLE_XCODE_SYSTEM_CORESIMULATOR_CACHE_DIR:-/Library/Developer/CoreSimulator/Caches}"
    [[ -d "$cache_root" ]] || return 0

    if _coresimulator_cache_process_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode Simulator system cache · skipped (CoreSimulator running)"
        note_activity
        return 0
    fi

    local -a cache_entries=()
    while IFS= read -r -d '' entry; do
        cache_entries+=("$entry")
    done < <(command find "$cache_root" -mindepth 1 -maxdepth 1 -print0 2> /dev/null)

    [[ ${#cache_entries[@]} -gt 0 ]] || return 0

    local entry

    if [[ "${DRY_RUN:-false}" == "true" ]]; then
        local total_size_kb=0
        local cleanable_count=0
        for entry in "${cache_entries[@]}"; do
            if should_protect_path "$entry" || is_path_whitelisted "$entry"; then
                continue
            fi
            local entry_size_kb
            entry_size_kb=$(get_path_size_kb "$entry" 2> /dev/null || echo 0)
            [[ "$entry_size_kb" =~ ^[0-9]+$ ]] || entry_size_kb=0
            if declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
                record_dry_run_cleanup_target "$entry" "$entry_size_kb" 1 true || continue
            fi
            total_size_kb=$((total_size_kb + entry_size_kb))
            cleanable_count=$((cleanable_count + 1))
        done
        [[ "$cleanable_count" -gt 0 ]] || return 0
        local total_size_human
        total_size_human=$(bytes_to_human "$((total_size_kb * 1024))")
        echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Xcode Simulator system cache · would remove ${cleanable_count} entries (${total_size_human})"
        note_activity
        return 0
    fi

    if ! has_sudo_session; then
        if ! ensure_sudo_session "Cleaning Xcode Simulator system cache requires admin access"; then
            echo -e "  ${YELLOW}${ICON_WARNING}${NC} Xcode Simulator system cache · skipped (sudo denied)"
            note_activity
            return 0
        fi
    fi

    local removed_count=0
    local removed_size_kb=0
    local skipped_count=0
    for entry in "${cache_entries[@]}"; do
        if should_protect_path "$entry" || is_path_whitelisted "$entry"; then
            skipped_count=$((skipped_count + 1))
            continue
        fi
        local entry_size_kb
        entry_size_kb=$(get_path_size_kb "$entry" 2> /dev/null || echo 0)
        [[ "$entry_size_kb" =~ ^[0-9]+$ ]] || entry_size_kb=0
        if safe_sudo_remove "$entry"; then
            removed_count=$((removed_count + 1))
            removed_size_kb=$((removed_size_kb + entry_size_kb))
        fi
    done

    if [[ $removed_count -gt 0 ]]; then
        local removed_human
        removed_human=$(bytes_to_human "$((removed_size_kb * 1024))")
        local line_color
        line_color=$(cleanup_result_color_kb "$removed_size_kb")
        if [[ $skipped_count -gt 0 ]]; then
            echo -e "  ${line_color}${ICON_SUCCESS}${NC} Xcode Simulator system cache · removed ${removed_count} (${line_color}${removed_human}${NC}), skipped ${skipped_count} protected"
        else
            echo -e "  ${line_color}${ICON_SUCCESS}${NC} Xcode Simulator system cache · removed ${removed_count} (${line_color}${removed_human}${NC})"
        fi
        note_activity
    elif [[ $skipped_count -gt 0 ]]; then
        echo -e "  ${YELLOW}${ICON_WARNING}${NC} Xcode Simulator system cache · skipped ${skipped_count} protected, none removed"
        note_activity
    else
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode Simulator system cache · already clean"
        note_activity
    fi
}

# Clean old Xcode DeviceSupport versions, keeping the most recent ones.
# Each version holds debug symbols (1-3 GB) for a specific iOS/watchOS/tvOS version.
# Symbols regenerate automatically when a device running that version is connected.
# Args: $1=directory path, $2=display name (e.g. "iOS DeviceSupport")
clean_xcode_device_support() {
    local ds_dir="$1"
    local display_name="$2"
    local keep_count="${MOLE_XCODE_DEVICE_SUPPORT_KEEP:-2}"
    [[ "$keep_count" =~ ^[0-9]+$ ]] || keep_count=2

    [[ -d "$ds_dir" ]] || return 0

    # Collect version directories (each is a platform version like "17.5 (21F79)")
    local -a version_dirs=()
    while IFS= read -r -d '' entry; do
        # Skip non-directories (e.g. .log files at the top level)
        [[ -d "$entry" ]] || continue
        version_dirs+=("$entry")
    done < <(command find "$ds_dir" -mindepth 1 -maxdepth 1 -print0 2> /dev/null)

    if [[ ${#version_dirs[@]} -gt 0 ]]; then
        # Sort by modification time (most recent first)
        local -a sorted_dirs=()
        while IFS= read -r line; do
            sorted_dirs+=("${line#* }")
        done < <(
            for entry in "${version_dirs[@]}"; do
                printf '%s %s\n' "$(stat -f%m "$entry" 2> /dev/null || echo 0)" "$entry"
            done | sort -rn
        )

        # Get stale versions (everything after keep_count)
        local -a stale_dirs=("${sorted_dirs[@]:$keep_count}")

        if [[ ${#stale_dirs[@]} -gt 0 ]]; then
            # Calculate total size of stale versions
            local stale_size_kb=0 entry_size_kb
            for stale_entry in "${stale_dirs[@]}"; do
                entry_size_kb=$(get_path_size_kb "$stale_entry" 2> /dev/null || echo 0)
                stale_size_kb=$((stale_size_kb + entry_size_kb))
            done
            local stale_size_human
            stale_size_human=$(bytes_to_human "$((stale_size_kb * 1024))")

            if [[ "$DRY_RUN" == "true" ]]; then
                local dry_run_count=0
                stale_size_kb=0
                for stale_entry in "${stale_dirs[@]}"; do
                    if should_protect_path "$stale_entry" || is_path_whitelisted "$stale_entry"; then
                        continue
                    fi
                    entry_size_kb=$(get_path_size_kb "$stale_entry" 2> /dev/null || echo 0)
                    [[ "$entry_size_kb" =~ ^[0-9]+$ ]] || entry_size_kb=0
                    if declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
                        record_dry_run_cleanup_target "$stale_entry" "$entry_size_kb" 1 true || continue
                    fi
                    stale_size_kb=$((stale_size_kb + entry_size_kb))
                    dry_run_count=$((dry_run_count + 1))
                done
                if [[ "$dry_run_count" -gt 0 ]]; then
                    stale_size_human=$(bytes_to_human "$((stale_size_kb * 1024))")
                    echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} ${display_name} · would remove ${dry_run_count} old versions (${stale_size_human}), keeping ${keep_count} most recent"
                    note_activity
                fi
            else
                # Remove old versions
                local removed_count=0
                for stale_entry in "${stale_dirs[@]}"; do
                    if should_protect_path "$stale_entry" || is_path_whitelisted "$stale_entry"; then
                        continue
                    fi
                    if safe_remove "$stale_entry"; then
                        removed_count=$((removed_count + 1))
                    fi
                done

                if [[ $removed_count -gt 0 ]]; then
                    local line_color
                    line_color=$(cleanup_result_color_kb "$stale_size_kb")
                    echo -e "  ${line_color}${ICON_SUCCESS}${NC} ${display_name} · removed ${removed_count} old versions, ${line_color}${stale_size_human}${NC}"
                    note_activity
                fi
            fi
        fi
    fi

    # Clean caches/logs inside kept versions
    safe_clean "$ds_dir"/*/Symbols/System/Library/Caches/* "$display_name symbol cache"
    safe_clean "$ds_dir"/*.log "$display_name logs"
}

_sim_runtime_mount_points() {
    if [[ -n "${MOLE_XCODE_SIM_RUNTIME_MOUNT_POINTS:-}" ]]; then
        printf '%s\n' "$MOLE_XCODE_SIM_RUNTIME_MOUNT_POINTS"
        return 0
    fi
    mount 2> /dev/null | command awk '{print $3}' || true
}

_sim_runtime_is_path_in_use() {
    local target_path="$1"
    shift || true
    local mount_path
    for mount_path in "$@"; do
        [[ -z "$mount_path" ]] && continue
        if [[ "$mount_path" == "$target_path" || "$mount_path" == "$target_path"/* ]]; then
            return 0
        fi
    done
    return 1
}

_sim_runtime_size_kb() {
    local target_path="$1"
    local size_kb=0
    if has_sudo_session; then
        size_kb=$(run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" sudo -n du -skP "$target_path" 2> /dev/null | command awk 'NR==1 {print $1; exit}' || echo "0")
    else
        size_kb=$(run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" du -skP "$target_path" 2> /dev/null | command awk 'NR==1 {print $1; exit}' || echo "0")
    fi

    [[ "$size_kb" =~ ^[0-9]+$ ]] || size_kb=0
    echo "$size_kb"
}

clean_xcode_simulator_runtime_volumes() {
    local volumes_root="${MOLE_XCODE_SIM_RUNTIME_VOLUMES_ROOT:-/Library/Developer/CoreSimulator/Volumes}"
    local cryptex_root="${MOLE_XCODE_SIM_RUNTIME_CRYPTEX_ROOT:-/Library/Developer/CoreSimulator/Cryptex}"

    local -a candidates=()
    local candidate
    for candidate in "$volumes_root" "$cryptex_root"; do
        [[ -d "$candidate" ]] || continue
        while IFS= read -r -d '' entry; do
            candidates+=("$entry")
        done < <(command find "$candidate" -mindepth 1 -maxdepth 1 -type d -print0 2> /dev/null)
    done

    if [[ ${#candidates[@]} -eq 0 ]]; then
        return 0
    fi

    local -a mount_points=()
    while IFS= read -r line; do
        [[ -n "$line" ]] && mount_points+=("$line")
    done < <(_sim_runtime_mount_points)

    # A real macOS system always mounts at least "/", so an empty list means
    # `mount` failed. Without this guard every candidate falls to the UNUSED
    # branch below and gets sudo-deleted, possibly while still mounted. Treat
    # "cannot enumerate mounts" as "cannot prove unused" and skip cleanup.
    if [[ ${#mount_points[@]} -eq 0 ]]; then
        return 0
    fi

    local -a entry_statuses=()
    local -a sorted_candidates=()
    local sorted
    while IFS= read -r sorted; do
        [[ -n "$sorted" ]] && sorted_candidates+=("$sorted")
    done < <(printf '%s\n' "${candidates[@]}" | LC_ALL=C sort)

    # Only show scanning message in debug mode; spinner provides visual feedback otherwise
    if [[ "${MO_DEBUG:-0}" == "1" ]]; then
        echo -e "  ${GRAY}${ICON_LIST}${NC} Xcode runtime volumes · scanning ${#sorted_candidates[@]} entries"
    fi
    local runtime_scan_spinner=false
    if [[ -t 1 ]]; then
        start_section_spinner "Scanning Xcode runtime volumes..."
        runtime_scan_spinner=true
    fi

    local in_use_count=0
    for candidate in "${sorted_candidates[@]}"; do
        local status="UNUSED"
        if [[ ${#mount_points[@]} -gt 0 ]] && _sim_runtime_is_path_in_use "$candidate" "${mount_points[@]}"; then
            status="IN_USE"
            in_use_count=$((in_use_count + 1))
        fi
        entry_statuses+=("$status")
    done

    if [[ "$DRY_RUN" == "true" ]]; then
        local -a size_values=()
        local in_use_kb=0
        local unused_kb=0
        local cleanable_unused_count=0
        local i=0
        for candidate in "${sorted_candidates[@]}"; do
            local size_kb
            size_kb=$(_sim_runtime_size_kb "$candidate")
            size_values+=("$size_kb")
            local status="${entry_statuses[$i]:-UNUSED}"
            if [[ "$status" == "IN_USE" ]]; then
                in_use_kb=$((in_use_kb + size_kb))
            else
                if ! should_protect_path "$candidate" && ! is_path_whitelisted "$candidate"; then
                    if declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
                        record_dry_run_cleanup_target "$candidate" "$size_kb" 1 true || {
                            i=$((i + 1))
                            continue
                        }
                    fi
                    unused_kb=$((unused_kb + size_kb))
                    cleanable_unused_count=$((cleanable_unused_count + 1))
                fi
            fi
            i=$((i + 1))
        done
        if [[ "$runtime_scan_spinner" == "true" ]]; then
            stop_section_spinner
            runtime_scan_spinner=false
        fi

        echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Xcode runtime volumes · ${cleanable_unused_count} unused, ${in_use_count} in use"
        local dryrun_total_kb=$((unused_kb + in_use_kb))
        local dryrun_total_human
        dryrun_total_human=$(bytes_to_human "$((dryrun_total_kb * 1024))")
        local dryrun_unused_human
        dryrun_unused_human=$(bytes_to_human "$((unused_kb * 1024))")
        local dryrun_in_use_human
        dryrun_in_use_human=$(bytes_to_human "$((in_use_kb * 1024))")
        echo -e "  ${GRAY}${ICON_LIST}${NC} Runtime volumes total: ${dryrun_total_human} (unused ${dryrun_unused_human}, in-use ${dryrun_in_use_human})"

        local dryrun_max_items="${MOLE_SIM_RUNTIME_DRYRUN_MAX_ITEMS:-20}"
        [[ "$dryrun_max_items" =~ ^[0-9]+$ ]] || dryrun_max_items=20
        if [[ "$dryrun_max_items" -le 0 ]]; then
            dryrun_max_items=20
        fi

        local shown=0
        local line_size_kb line_status line_path
        while IFS=$'\t' read -r line_size_kb line_status line_path; do
            [[ -z "${line_path:-}" ]] && continue
            local line_human
            line_human=$(bytes_to_human "$((line_size_kb * 1024))")
            echo -e "    ${GRAY}${line_status}${NC} ${line_human} · ${line_path}"
            shown=$((shown + 1))
            if [[ "$shown" -ge "$dryrun_max_items" ]]; then
                break
            fi
        done < <(
            local j=0
            while [[ $j -lt ${#sorted_candidates[@]} ]]; do
                printf '%s\t%s\t%s\n' "${size_values[$j]:-0}" "${entry_statuses[$j]:-UNUSED}" "${sorted_candidates[$j]}"
                j=$((j + 1))
            done | LC_ALL=C sort -nr -k1,1
        )

        local total_entries="${#sorted_candidates[@]}"
        if [[ "$total_entries" -gt "$shown" ]]; then
            local remaining=$((total_entries - shown))
            echo -e "    ${GRAY}${ICON_LIST}${NC} ... and ${remaining} more runtime volume entries"
        fi
        note_activity
        return 0
    fi

    # Auto-clean all UNUSED runtime volumes (no user selection)
    local -a selected_paths=()
    local skipped_protected=0
    local i=0
    for ((i = 0; i < ${#sorted_candidates[@]}; i++)); do
        local status="${entry_statuses[$i]:-UNUSED}"
        [[ "$status" == "IN_USE" ]] && continue

        local candidate_path="${sorted_candidates[$i]}"
        if should_protect_path "$candidate_path" || is_path_whitelisted "$candidate_path"; then
            skipped_protected=$((skipped_protected + 1))
            continue
        fi
        selected_paths+=("$candidate_path")
    done

    if [[ "$runtime_scan_spinner" == "true" ]]; then
        stop_section_spinner
        runtime_scan_spinner=false
    fi

    if [[ ${#selected_paths[@]} -eq 0 ]]; then
        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode runtime volumes · already clean"
        note_activity
        return 0
    fi

    if ! has_sudo_session; then
        if ! ensure_sudo_session "Cleaning Xcode runtime volumes requires admin access"; then
            echo -e "  ${YELLOW}${ICON_WARNING}${NC} Xcode runtime volumes · skipped (sudo denied)"
            note_activity
            return 0
        fi
    fi

    # Perform cleanup and report final result in one line
    local removed_count=0
    local removed_size_kb=0
    local selected_path
    for selected_path in "${selected_paths[@]}"; do
        local selected_size_kb=0
        selected_size_kb=$(_sim_runtime_size_kb "$selected_path")
        if safe_sudo_remove "$selected_path"; then
            removed_count=$((removed_count + 1))
            removed_size_kb=$((removed_size_kb + selected_size_kb))
        fi
    done

    # Unified output: report result, not intermediate steps
    if [[ $removed_count -gt 0 ]]; then
        local removed_human
        removed_human=$(bytes_to_human "$((removed_size_kb * 1024))")
        local line_color
        line_color=$(cleanup_result_color_kb "$removed_size_kb")
        if [[ $skipped_protected -gt 0 ]]; then
            echo -e "  ${line_color}${ICON_SUCCESS}${NC} Xcode runtime volumes · removed ${removed_count} (${line_color}${removed_human}${NC}), skipped ${skipped_protected} protected"
        else
            echo -e "  ${line_color}${ICON_SUCCESS}${NC} Xcode runtime volumes · removed ${removed_count} (${line_color}${removed_human}${NC})"
        fi
        note_activity
    else
        if [[ $skipped_protected -gt 0 ]]; then
            echo -e "  ${YELLOW}${ICON_WARNING}${NC} Xcode runtime volumes · skipped ${skipped_protected} protected, none removed"
        else
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode runtime volumes · already clean"
        fi
        note_activity
    fi
}

_MOLE_SIMCTL_DEVELOPER_DIR=""
_MOLE_SIMCTL_RESOLUTION_STATUS="unavailable"
_MOLE_SIMCTL_XCODE_APP_ROOTS=(
    "/Applications"
    "$HOME/Applications"
)

_simctl_developer_dir_is_usable() {
    local developer_dir="$1"
    [[ -d "$developer_dir" ]] || return 1

    run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        env "DEVELOPER_DIR=$developer_dir" xcrun --find simctl > /dev/null 2>&1
}

# Resolve simctl without changing the machine-wide xcode-select setting.
# An explicit DEVELOPER_DIR is authoritative: if it is invalid, do not
# silently switch the caller to a different Xcode installation.
_resolve_simctl_developer_dir() {
    _MOLE_SIMCTL_DEVELOPER_DIR=""
    _MOLE_SIMCTL_RESOLUTION_STATUS="unavailable"

    if [[ -n "${DEVELOPER_DIR:-}" ]]; then
        if _simctl_developer_dir_is_usable "$DEVELOPER_DIR"; then
            _MOLE_SIMCTL_DEVELOPER_DIR="$DEVELOPER_DIR"
            _MOLE_SIMCTL_RESOLUTION_STATUS="ready"
            return 0
        fi

        _MOLE_SIMCTL_RESOLUTION_STATUS="explicit-invalid"
        debug_log "Explicit DEVELOPER_DIR does not provide simctl: $DEVELOPER_DIR"
        return 1
    fi

    local selected_developer_dir=""
    if command -v xcode-select > /dev/null 2>&1; then
        selected_developer_dir=$(xcode-select -p 2> /dev/null || true)
    fi
    case "$selected_developer_dir" in
        /Library/Developer/CommandLineTools | /Library/Developer/CommandLineTools/)
            ;;
        "")
            return 1
            ;;
        *)
            if _simctl_developer_dir_is_usable "$selected_developer_dir"; then
                _MOLE_SIMCTL_DEVELOPER_DIR="$selected_developer_dir"
                _MOLE_SIMCTL_RESOLUTION_STATUS="ready"
                return 0
            fi
            debug_log "Selected Xcode does not provide simctl: $selected_developer_dir"
            return 1
            ;;
    esac

    local -a candidates=()
    local app_root candidate_app candidate_developer_dir
    local nullglob_was_set=0
    shopt -q nullglob && nullglob_was_set=1
    shopt -s nullglob
    for app_root in "${_MOLE_SIMCTL_XCODE_APP_ROOTS[@]}"; do
        [[ -d "$app_root" ]] || continue
        for candidate_app in "$app_root"/Xcode*.app; do
            [[ -d "$candidate_app" ]] || continue
            candidate_developer_dir="$candidate_app/Contents/Developer"
            if _simctl_developer_dir_is_usable "$candidate_developer_dir"; then
                candidates+=("$candidate_developer_dir")
            fi
        done
    done
    if [[ $nullglob_was_set -eq 0 ]]; then
        shopt -u nullglob
    fi

    if [[ ${#candidates[@]} -eq 1 ]]; then
        _MOLE_SIMCTL_DEVELOPER_DIR="${candidates[0]}"
        _MOLE_SIMCTL_RESOLUTION_STATUS="ready"
        debug_log "Using detected Xcode for simctl: ${candidates[0]%/Contents/Developer}"
        return 0
    fi

    if [[ ${#candidates[@]} -gt 1 ]]; then
        _MOLE_SIMCTL_RESOLUTION_STATUS="ambiguous"
        for candidate_developer_dir in "${candidates[@]}"; do
            debug_log "simctl Xcode candidate: ${candidate_developer_dir%/Contents/Developer}"
        done
    fi

    return 1
}

_run_simctl() {
    local timeout_seconds="$1"
    shift

    [[ "$_MOLE_SIMCTL_RESOLUTION_STATUS" == "ready" ]] || return 127
    run_with_timeout "$timeout_seconds" \
        env "DEVELOPER_DIR=$_MOLE_SIMCTL_DEVELOPER_DIR" xcrun simctl "$@"
}

clean_dev_mobile() {
    check_android_ndk
    clean_xcode_documentation_cache
    clean_xcode_system_coresimulator_caches
    clean_xcode_simulator_runtime_volumes
    clean_xcode_xctest_devices

    if command -v xcrun > /dev/null 2>&1; then
        _resolve_simctl_developer_dir || true
        if [[ "$_MOLE_SIMCTL_RESOLUTION_STATUS" == "ambiguous" ]]; then
            echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators · multiple Xcode apps found; set DEVELOPER_DIR"
            note_activity
        elif [[ "$_MOLE_SIMCTL_RESOLUTION_STATUS" == "explicit-invalid" ]]; then
            echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators · DEVELOPER_DIR has no simctl"
            note_activity
        elif [[ "$_MOLE_SIMCTL_RESOLUTION_STATUS" == "ready" ]]; then
            debug_log "Checking for unavailable Xcode simulators"
            local unavailable_before=0
            local unavailable_after=0
            local removed_unavailable=0
            local unavailable_size_kb=0
            local unavailable_size_human="0B"
            local -a unavailable_udids=()
            local unavailable_udid=""

            # Check if simctl is accessible and working; timeout prevents hang when CLT-only.
            # CoreSimulatorService may need >2s to warm up on cold boot, so we retry once
            # with a longer timeout. See #890.
            local simctl_available=true
            local simctl_probe_ok=false
            if _run_simctl "$MOLE_TIMEOUT_MEDIUM_PROBE_SEC" list devices > /dev/null 2>&1; then
                simctl_probe_ok=true
            else
                if _run_simctl 8 list devices > /dev/null 2>&1; then # 8s: simctl retry after warmup, see lib/core/timeouts.sh
                    simctl_probe_ok=true
                    debug_log "simctl probe succeeded on retry (CoreSimulatorService warmup)"
                else
                    debug_log "simctl probe failed after retry (5s + 8s timeouts)"
                fi
            fi
            if [[ "$simctl_probe_ok" != "true" ]]; then
                debug_log "simctl not accessible or CoreSimulator service not running"
                echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators · simctl not available"
                note_activity
                simctl_available=false
            fi

            if [[ "$simctl_available" == "true" ]]; then
                local unavailable_devices_output=""
                local unavailable_list_exit_code=0
                unavailable_devices_output=$(_run_simctl "$MOLE_TIMEOUT_PKG_LIST_SEC" list devices unavailable 2> /dev/null) || unavailable_list_exit_code=$?
                if [[ $unavailable_list_exit_code -ne 0 ]]; then
                    echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators · simctl list failed (exit=${unavailable_list_exit_code})"
                    debug_log "simctl list devices unavailable returned $unavailable_list_exit_code"
                    note_activity
                    simctl_available=false
                fi
            fi

            if [[ "$simctl_available" == "true" ]]; then
                unavailable_before=$(printf '%s\n' "$unavailable_devices_output" | command awk '/\(unavailable/ { count++ } END { print count+0 }')
                [[ "$unavailable_before" =~ ^[0-9]+$ ]] || unavailable_before=0
                while IFS= read -r unavailable_udid; do
                    [[ -n "$unavailable_udid" ]] && unavailable_udids+=("$unavailable_udid")
                done < <(
                    printf '%s\n' "$unavailable_devices_output" |
                        command sed -nE 's/.*\(([0-9A-Fa-f-]{36})\).*\(unavailable.*/\1/p' || true
                )
                if [[ ${#unavailable_udids[@]} -gt 0 ]]; then
                    local udid
                    for udid in "${unavailable_udids[@]}"; do
                        local simulator_device_path="$HOME/Library/Developer/CoreSimulator/Devices/$udid"
                        if [[ -d "$simulator_device_path" ]]; then
                            unavailable_size_kb=$((unavailable_size_kb + $(get_path_size_kb "$simulator_device_path")))
                        fi
                    done
                fi
                unavailable_size_human=$(bytes_to_human "$((unavailable_size_kb * 1024))")

                if [[ "$DRY_RUN" == "true" ]]; then
                    if ((unavailable_before > 0)); then
                        for unavailable_udid in "${unavailable_udids[@]}"; do
                            local unavailable_path="$HOME/Library/Developer/CoreSimulator/Devices/$unavailable_udid"
                            [[ -d "$unavailable_path" ]] || continue
                            local unavailable_path_size_kb
                            unavailable_path_size_kb=$(get_path_size_kb "$unavailable_path" 2> /dev/null || echo "0")
                            [[ "$unavailable_path_size_kb" =~ ^[0-9]+$ ]] || unavailable_path_size_kb=0
                            if declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
                                record_dry_run_cleanup_target "$unavailable_path" "$unavailable_path_size_kb" 1 true || true
                            fi
                        done
                        echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Xcode unavailable simulators · would clean ${unavailable_before}, ${unavailable_size_human}"
                    else
                        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode unavailable simulators · already clean"
                    fi
                    note_activity
                else
                    # Skip if no unavailable simulators
                    if ((unavailable_before == 0)); then
                        echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Xcode unavailable simulators · already clean"
                        note_activity
                    else
                        start_section_spinner "Checking unavailable simulators..."

                        # Capture error output for diagnostics
                        local delete_output
                        local delete_exit_code=0
                        delete_output=$(_run_simctl "$MOLE_TIMEOUT_PKG_CLEANUP_SEC" delete unavailable 2>&1) || delete_exit_code=$?

                        if [[ $delete_exit_code -eq 0 ]]; then
                            stop_section_spinner
                            local recount_exit_code=0
                            unavailable_devices_output=$(_run_simctl "$MOLE_TIMEOUT_PKG_LIST_SEC" list devices unavailable 2> /dev/null) || recount_exit_code=$?
                            if [[ $recount_exit_code -ne 0 ]]; then
                                echo -e "  ${YELLOW}${ICON_WARNING}${NC} Xcode unavailable simulators · cleanup completed, unable to verify remaining devices"
                                debug_log "simctl recount returned $recount_exit_code"
                            else
                                unavailable_after=$(printf '%s\n' "$unavailable_devices_output" | command awk '/\(unavailable/ { count++ } END { print count+0 }')
                                [[ "$unavailable_after" =~ ^[0-9]+$ ]] || unavailable_after=0

                                removed_unavailable=$((unavailable_before - unavailable_after))
                                if ((removed_unavailable < 0)); then
                                    removed_unavailable=0
                                fi

                                local line_color
                                line_color=$(cleanup_result_color_kb "$unavailable_size_kb")
                                if ((removed_unavailable > 0)); then
                                    echo -e "  ${line_color}${ICON_SUCCESS}${NC} Xcode unavailable simulators · removed ${removed_unavailable}, ${line_color}${unavailable_size_human}${NC}"
                                else
                                    echo -e "  ${line_color}${ICON_SUCCESS}${NC} Xcode unavailable simulators · cleanup completed, ${line_color}${unavailable_size_human}${NC}"
                                fi
                            fi
                        else
                            stop_section_spinner

                            # Analyze error and provide helpful message
                            local error_hint=""
                            if echo "$delete_output" | grep -qi "permission denied"; then
                                error_hint=" (permission denied)"
                            elif echo "$delete_output" | grep -qi "in use\|busy"; then
                                error_hint=" (device in use)"
                            elif echo "$delete_output" | grep -qi "unable to boot\|failed to boot"; then
                                error_hint=" (boot failure)"
                            elif echo "$delete_output" | grep -qi "service"; then
                                error_hint=" (CoreSimulator service issue)"
                            fi

                            # Native simctl owns simulator state. A nonzero result can
                            # mean the device became active after the list, so never
                            # bypass it with direct directory removal.
                            if [[ $delete_exit_code -eq 124 ]]; then
                                echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators · cleanup timed out"
                                debug_log "simctl delete unavailable timed out"
                            else
                                echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators cleanup failed${error_hint}"
                                debug_log "simctl delete error: $delete_output"
                            fi
                        fi
                    fi
                fi # Close if ((unavailable_before == 0))
                note_activity
            fi # End of simctl_available check
        else
            echo -e "  ${GRAY}${ICON_WARNING}${NC} Xcode unavailable simulators · simctl not available"
            note_activity
        fi
    fi
    # Old iOS/watchOS/tvOS DeviceSupport versions (debug symbols for connected devices).
    # Each iOS version creates a 1-3 GB folder of debug symbols. Only the versions
    # matching currently used devices are needed; older ones regenerate on device connect.
    clean_xcode_device_support ~/Library/Developer/Xcode/iOS\ DeviceSupport "iOS DeviceSupport"
    clean_xcode_device_support ~/Library/Developer/Xcode/watchOS\ DeviceSupport "watchOS DeviceSupport"
    clean_xcode_device_support ~/Library/Developer/Xcode/tvOS\ DeviceSupport "tvOS DeviceSupport"
    # Simulator runtime caches.
    safe_clean ~/Library/Developer/CoreSimulator/Profiles/Runtimes/*/Contents/Resources/RuntimeRoot/System/Library/Caches/* "Simulator runtime cache"
    safe_clean ~/Library/Caches/Google/AndroidStudio*/* "Android Studio cache"
    # safe_clean ~/Library/Caches/CocoaPods/* "CocoaPods cache"
    # safe_clean ~/.cache/flutter/* "Flutter cache"
    safe_clean ~/.android/build-cache/* "Android build cache"
    safe_clean ~/.android/cache/* "Android SDK cache"
    safe_clean ~/Library/Developer/Xcode/UserData/IB\ Support/* "Xcode Interface Builder cache"
    safe_clean ~/.cache/swift-package-manager/* "Swift package manager cache"
    safe_clean ~/Library/Caches/org.swift.swiftpm/* "Swift package manager library cache"
    # Expo/React Native caches (preserve state.json which contains auth tokens).
    safe_clean ~/.expo/expo-go/* "Expo Go cache"
    safe_clean ~/.expo/android-apk-cache/* "Expo Android APK cache"
    safe_clean ~/.expo/ios-simulator-app-cache/* "Expo iOS simulator app cache"
    safe_clean ~/.expo/native-modules-cache/* "Expo native modules cache"
    safe_clean ~/.expo/schema-cache/* "Expo schema cache"
    safe_clean ~/.expo/template-cache/* "Expo template cache"
    safe_clean ~/.expo/versions-cache/* "Expo versions cache"
}
# JVM ecosystem caches.
# Gradle: Respects whitelist, cleaned when not protected via: mo clean --whitelist
clean_dev_jvm() {
    # Source Maven cleanup module (requires bash for BASH_SOURCE)
    # shellcheck disable=SC1091
    source "$(dirname "${BASH_SOURCE[0]}")/maven.sh" 2> /dev/null || true
    if declare -f clean_maven_repository > /dev/null 2>&1; then
        clean_maven_repository
    fi
    safe_clean ~/.sbt/boot/* "SBT boot cache"
    safe_clean ~/.sbt/launchers/* "SBT launcher cache"
    safe_clean ~/.ivy2/cache/* "Ivy cache"
    safe_clean ~/.gradle/caches/build-cache-*/* "Gradle build cache"
    safe_clean ~/.gradle/notifications/* "Gradle notifications cache"
    if gradle_daemon_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Gradle daemon/workers · skipped (Gradle daemon running)"
        note_activity
    else
        safe_clean ~/.gradle/daemon/* "Gradle daemon"
        safe_clean ~/.gradle/workers/* "Gradle workers"
    fi
}
# JetBrains Toolbox old IDE versions (keep current + recent backup).
clean_dev_jetbrains_toolbox() {
    local toolbox_root="$HOME/Library/Application Support/JetBrains/Toolbox/apps"
    [[ -d "$toolbox_root" ]] || return 0

    local keep_previous="${MOLE_JETBRAINS_TOOLBOX_KEEP:-1}"
    [[ "$keep_previous" =~ ^[0-9]+$ ]] || keep_previous=1

    # Save and filter whitelist patterns for toolbox path
    local whitelist_overridden="false"
    local -a original_whitelist=()
    if [[ ${#WHITELIST_PATTERNS[@]} -gt 0 ]]; then
        original_whitelist=("${WHITELIST_PATTERNS[@]}")
        local -a filtered_whitelist=()
        local pattern
        for pattern in "${WHITELIST_PATTERNS[@]}"; do
            [[ "$toolbox_root" == "$pattern" || "$pattern" == "$toolbox_root"* ]] && continue
            filtered_whitelist+=("$pattern")
        done
        WHITELIST_PATTERNS=("${filtered_whitelist[@]+${filtered_whitelist[@]}}")
        whitelist_overridden="true"
    fi

    # Helper to restore whitelist on exit
    _restore_whitelist() {
        [[ "$whitelist_overridden" == "true" ]] && WHITELIST_PATTERNS=("${original_whitelist[@]}")
        return 0
    }

    local -a product_dirs=()
    while IFS= read -r -d '' product_dir; do
        product_dirs+=("$product_dir")
    done < <(command find "$toolbox_root" -mindepth 1 -maxdepth 1 -type d -print0 2> /dev/null)

    if [[ ${#product_dirs[@]} -eq 0 ]]; then
        _restore_whitelist
        return 0
    fi

    local product_dir
    for product_dir in "${product_dirs[@]}"; do
        while IFS= read -r -d '' channel_dir; do
            local current_link=""
            local current_real=""
            if [[ -L "$channel_dir/current" ]]; then
                current_link=$(readlink "$channel_dir/current" 2> /dev/null || true)
                if [[ -n "$current_link" ]]; then
                    if [[ "$current_link" == /* ]]; then
                        current_real="$current_link"
                    else
                        current_real="$channel_dir/$current_link"
                    fi
                fi
            elif [[ -d "$channel_dir/current" ]]; then
                current_real="$channel_dir/current"
            fi

            local -a version_dirs=()
            while IFS= read -r -d '' version_dir; do
                local name
                name=$(basename "$version_dir")

                [[ "$name" == "current" ]] && continue
                [[ "$name" == .* ]] && continue
                [[ "$name" == "plugins" || "$name" == "plugins-lib" || "$name" == "plugins-libs" ]] && continue
                [[ -n "$current_real" && "$version_dir" == "$current_real" ]] && continue
                [[ ! "$name" =~ ^[0-9] ]] && continue

                version_dirs+=("$version_dir")
            done < <(command find "$channel_dir" -mindepth 1 -maxdepth 1 -type d -print0 2> /dev/null)

            [[ ${#version_dirs[@]} -eq 0 ]] && continue

            local -a sorted_dirs=()
            while IFS= read -r line; do
                local dir_path="${line#* }"
                sorted_dirs+=("$dir_path")
            done < <(
                for version_dir in "${version_dirs[@]}"; do
                    local mtime
                    mtime=$(stat -f%m "$version_dir" 2> /dev/null || echo "0")
                    printf '%s %s\n' "$mtime" "$version_dir"
                done | sort -rn
            )

            if [[ ${#sorted_dirs[@]} -le "$keep_previous" ]]; then
                continue
            fi

            local idx=0
            local dir_path
            for dir_path in "${sorted_dirs[@]}"; do
                if [[ $idx -lt $keep_previous ]]; then
                    idx=$((idx + 1))
                    continue
                fi
                safe_clean "$dir_path" "JetBrains Toolbox old IDE version"
                note_activity
                idx=$((idx + 1))
            done
        done < <(command find "$product_dir" -mindepth 1 -maxdepth 1 -type d -name "ch-*" -print0 2> /dev/null)
    done

    _restore_whitelist
}

# JetBrains IDE logs are safe to rebuild, unlike some cache subtrees that can
# invalidate IDE indexes and trigger expensive reindexing.
clean_dev_jetbrains_logs() {
    safe_clean ~/Library/Logs/JetBrains/* "JetBrains IDE logs"
}

# AI coding agents (Claude Code, Cursor Agent, etc.) auto-update but never
# remove previous versions, so ~/.local/share/<agent>/versions accumulates
# hundreds of MB per release. Keep the most recently modified N entries
# plus the version pointed at by the active CLI symlink (mtime alone is
# unreliable: Claude Code pre-downloads the next version before flipping
# the symlink, so newest mtime is not always the active version).
clean_versioned_agent_root() {
    local versions_root="$1"
    local label="$2"
    local keep_previous="$3"
    local active_path="${4:-}"

    [[ -d "$versions_root" ]] || return 0

    local -a entries=()
    local entry
    while IFS= read -r -d '' entry; do
        local name
        name=$(basename "$entry")
        [[ "$name" == .* ]] && continue
        [[ ! "$name" =~ ^[0-9] ]] && continue
        entries+=("$entry")
    done < <(command find "$versions_root" -mindepth 1 -maxdepth 1 \( -type f -o -type d \) -print0 2> /dev/null)

    [[ ${#entries[@]} -le "$keep_previous" ]] && return 0

    local -a sorted=()
    local line
    while IFS= read -r line; do
        sorted+=("${line#* }")
    done < <(
        local version_entry
        for version_entry in "${entries[@]}"; do
            local mtime
            mtime=$(stat -f%m "$version_entry" 2> /dev/null || echo "0")
            printf '%s %s\n' "$mtime" "$version_entry"
        done | sort -rn
    )

    local idx=0
    local target
    for target in "${sorted[@]}"; do
        if [[ -n "$active_path" && "$target" == "$active_path" ]]; then
            continue
        fi
        if [[ $idx -lt $keep_previous ]]; then
            idx=$((idx + 1))
            continue
        fi
        safe_clean "$target" "$label"
        note_activity
        idx=$((idx + 1))
    done
}

count_versioned_agent_entries() {
    local versions_root="$1"
    local count=0
    local entry

    [[ -d "$versions_root" ]] || {
        echo 0
        return 0
    }

    while IFS= read -r -d '' entry; do
        local name
        name=$(basename "$entry")
        [[ "$name" == .* ]] && continue
        [[ ! "$name" =~ ^[0-9] ]] && continue
        count=$((count + 1))
    done < <(command find "$versions_root" -mindepth 1 -maxdepth 1 \( -type f -o -type d \) -print0 2> /dev/null)

    echo "$count"
}

claude_desktop_sdk_version_is_safe() {
    local sdk_version="${1:-}"

    [[ -n "$sdk_version" ]] || return 1
    [[ "$sdk_version" == .* ]] && return 1
    [[ "$sdk_version" == *"/"* ]] && return 1
    [[ "$sdk_version" == *".."* ]] && return 1
    [[ "$sdk_version" =~ ^[0-9] ]] || return 1
    return 0
}

claude_desktop_running() {
    command -v pgrep > /dev/null 2>&1 || return 1

    pgrep -x "Claude" > /dev/null 2>&1 && return 0
    pgrep -f "/Claude.app/" > /dev/null 2>&1 && return 0
    return 1
}

claude_desktop_sdk_version() {
    local claude_support="$1"
    local sdk_file="$claude_support/claude-code-vm/.sdk-version"
    [[ -f "$sdk_file" ]] || return 1

    local sdk_version
    sdk_version=$(head -n 1 "$sdk_file" 2> /dev/null | LC_ALL=C tr -d '[:space:]' || true)
    claude_desktop_sdk_version_is_safe "$sdk_version" || return 1

    printf '%s\n' "$sdk_version"
}

clean_claude_desktop_bundled_versions() {
    local keep_previous="$1"
    local claude_support="$HOME/Library/Application Support/Claude"
    [[ -d "$claude_support" ]] || return 0

    local -a desktop_specs=(
        "$claude_support/claude-code|Claude Desktop bundled Claude Code old version"
        "$claude_support/claude-code-vm|Claude Desktop bundled Claude Code VM old version"
    )

    local has_multiple_versions=false
    local spec
    for spec in "${desktop_specs[@]}"; do
        local versions_root="${spec%%|*}"
        [[ -d "$versions_root" ]] || continue

        local version_count
        version_count=$(count_versioned_agent_entries "$versions_root")
        [[ "$version_count" =~ ^[0-9]+$ ]] || version_count=0
        if [[ "$version_count" -gt 1 ]]; then
            has_multiple_versions=true
            break
        fi
    done

    [[ "$has_multiple_versions" == "true" ]] || return 0

    if claude_desktop_running; then
        note_activity
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Claude Desktop bundled Claude Code · skipped (Claude Desktop running)"
        return 0
    fi

    local sdk_version=""
    sdk_version=$(claude_desktop_sdk_version "$claude_support" || true)
    if [[ -z "$sdk_version" ]]; then
        note_activity
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Claude Desktop bundled Claude Code · skipped (active version unknown)"
        return 0
    fi

    for spec in "${desktop_specs[@]}"; do
        local versions_root="${spec%%|*}"
        local label="${spec#*|}"
        [[ -d "$versions_root" ]] || continue

        if [[ ! -e "$versions_root/$sdk_version" ]]; then
            note_activity
            echo -e "  ${GRAY}${ICON_WARNING}${NC} $label · skipped (active version unknown)"
            return 0
        fi
    done

    for spec in "${desktop_specs[@]}"; do
        local versions_root="${spec%%|*}"
        local label="${spec#*|}"
        [[ -d "$versions_root" ]] || continue

        local version_count
        version_count=$(count_versioned_agent_entries "$versions_root")
        [[ "$version_count" =~ ^[0-9]+$ ]] || version_count=0
        [[ "$version_count" -le 1 ]] && continue

        clean_versioned_agent_root "$versions_root" "$label" "$keep_previous" "$versions_root/$sdk_version"
    done
}

clean_dev_ai_agents() {
    local keep_previous="${MOLE_AI_AGENTS_KEEP:-1}"
    [[ "$keep_previous" =~ ^[0-9]+$ ]] || keep_previous=1

    local -a agent_specs=(
        "$HOME/.local/share/claude/versions|Claude Code old version|$HOME/.local/bin/claude"
        "$HOME/.local/share/cursor-agent/versions|Cursor Agent old version|$HOME/.local/bin/cursor-agent"
        "$HOME/.copilot/pkg/universal|GitHub Copilot CLI old version|$HOME/.local/bin/copilot"
    )

    local spec
    for spec in "${agent_specs[@]}"; do
        local versions_root="${spec%%|*}"
        local rest="${spec#*|}"
        local label="${rest%%|*}"
        local active_symlink="${rest#*|}"
        [[ "$active_symlink" == "$rest" ]] && active_symlink=""
        [[ -d "$versions_root" ]] || continue

        local active_path=""
        if [[ -n "$active_symlink" && -L "$active_symlink" ]]; then
            if [[ ! -e "$active_symlink" ]]; then
                echo -e "  ${GRAY}${ICON_WARNING}${NC} $label · skipped (active symlink broken)"
                note_activity
                continue
            fi
            local target
            target=$(readlink "$active_symlink" 2> /dev/null || true)
            if [[ -z "$target" ]]; then
                echo -e "  ${GRAY}${ICON_WARNING}${NC} $label · skipped (active version unknown)"
                note_activity
                continue
            fi
            case "$target" in
                /*) ;;
                *) target="$(dirname "$active_symlink")/$target" ;;
            esac

            # Resolve dot segments and symlinked parent directories before
            # comparing. Launchers commonly use ../../relative targets, and a
            # lexical comparison would fail to pin the active version.
            local target_parent target_name
            target_parent=$(dirname "$target")
            target_name=$(basename "$target")
            if ! target_parent=$(cd "$target_parent" 2> /dev/null && pwd -P); then
                echo -e "  ${GRAY}${ICON_WARNING}${NC} $label · skipped (active version unknown)"
                note_activity
                continue
            fi
            target="$target_parent/$target_name"

            local entry entry_resolved entry_parent entry_name
            for entry in "$versions_root"/*; do
                [[ -e "$entry" ]] || continue
                if [[ -d "$entry" ]]; then
                    entry_resolved=$(cd "$entry" 2> /dev/null && pwd -P) || continue
                else
                    entry_parent=$(dirname "$entry")
                    entry_name=$(basename "$entry")
                    entry_parent=$(cd "$entry_parent" 2> /dev/null && pwd -P) || continue
                    entry_resolved="$entry_parent/$entry_name"
                fi
                case "$target/" in
                    "$entry_resolved"/*)
                        active_path="$entry"
                        break
                        ;;
                esac
            done
            if [[ -z "$active_path" ]]; then
                echo -e "  ${GRAY}${ICON_WARNING}${NC} $label · skipped (active version unknown)"
                note_activity
                continue
            fi
        fi

        clean_versioned_agent_root "$versions_root" "$label" "$keep_previous" "$active_path"
    done

    clean_claude_desktop_bundled_versions "$keep_previous"
}

# Other language tool caches.
clean_dev_other_langs() {
    safe_clean ~/.composer/cache/* "PHP Composer cache (legacy)"
    safe_clean ~/Library/Caches/composer/* "PHP Composer cache"
    safe_clean ~/.nuget/packages/* "NuGet packages cache"
    # safe_clean ~/.pub-cache/* "Dart Pub cache"
    safe_clean ~/.cache/bazel/* "Bazel cache"
    safe_clean ~/.cache/zig/* "Zig cache"
    safe_clean ~/Library/Caches/deno/* "Deno cache"
}
# CI/CD and DevOps caches.
clean_dev_cicd() {
    safe_clean ~/.cache/terraform/* "Terraform cache"
    safe_clean ~/.grafana/cache/* "Grafana cache"
    safe_clean ~/.prometheus/data/wal/* "Prometheus WAL cache"
    safe_clean ~/.jenkins/workspace/*/target/* "Jenkins workspace cache"
    safe_clean ~/.cache/gitlab-runner/* "GitLab Runner cache"
    safe_clean ~/.github/cache/* "GitHub Actions cache"
    safe_clean ~/.circleci/cache/* "CircleCI cache"
    safe_clean ~/.sonar/* "SonarQube cache"
}
# Database tool caches.
clean_dev_database() {
    safe_clean ~/Library/Caches/com.sequel-ace.sequel-ace/* "Sequel Ace cache"
    safe_clean ~/Library/Caches/com.eggerapps.Sequel-Pro/* "Sequel Pro cache"
    safe_clean ~/Library/Caches/redis-desktop-manager/* "Redis Desktop Manager cache"
    safe_clean ~/Library/Caches/com.navicat.* "Navicat cache"
    safe_clean ~/Library/Caches/com.dbeaver.* "DBeaver cache"
    safe_clean ~/Library/Caches/com.redis.RedisInsight "Redis Insight cache"
}
# API/debugging tool caches.
clean_dev_api_tools() {
    safe_clean ~/Library/Caches/com.postmanlabs.mac/* "Postman cache"
    safe_clean ~/Library/Caches/com.konghq.insomnia/* "Insomnia cache"
    safe_clean ~/Library/Caches/com.tinyapp.TablePlus/* "TablePlus cache"
    safe_clean ~/Library/Caches/com.getpaw.Paw/* "Paw API cache"
    safe_clean ~/Library/Caches/com.charlesproxy.charles/* "Charles Proxy cache"
    safe_clean ~/Library/Caches/com.proxyman.NSProxy/* "Proxyman cache"
}

codex_desktop_running() {
    command -v pgrep > /dev/null 2>&1 || return 1

    pgrep -x "Codex" > /dev/null 2>&1 && return 0
    pgrep -f "/Codex.app/" > /dev/null 2>&1 && return 0
    return 1
}

codex_sparkle_updater_running() {
    command -v pgrep > /dev/null 2>&1 || return 1

    pgrep -f "org[.]sparkle-project[.]Sparkle" > /dev/null 2>&1 && return 0
    pgrep -f "Sparkle[.]framework/.*/(Autoupdate|Installer|Downloader|Updater)" > /dev/null 2>&1 && return 0
    return 1
}

codex_sparkle_staging_has_open_files() {
    local staging_root="$1"
    command -v lsof > /dev/null 2>&1 || return 1

    local lsof_output=""
    local lsof_rc=0
    if lsof_output=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" lsof -Fn +D "$staging_root" 2> /dev/null); then
        [[ -n "$lsof_output" ]]
        return
    else
        lsof_rc=$?
    fi

    # `lsof +D` returns 1 when no open files match. Timeouts or other failures
    # are different: the caller must conservatively skip cleanup.
    [[ "$lsof_rc" -eq 1 ]] && return 1
    return 2
}

clean_codex_desktop_staging() {
    local staging_root="$HOME/Library/Caches/com.openai.codex/org.sparkle-project.Sparkle/Installation"
    [[ -d "$staging_root" ]] || return 0

    local entry_count=0
    entry_count=$(command find -P "$staging_root" -mindepth 1 -maxdepth 1 -type d -print 2> /dev/null | wc -l | tr -d ' ')
    [[ "$entry_count" =~ ^[0-9]+$ ]] || entry_count=0
    [[ "$entry_count" -gt 0 ]] || return 0

    if is_path_whitelisted "$staging_root"; then
        if [[ "${DRY_RUN:-false}" == "true" ]]; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Codex Desktop update staging · would skip (whitelist)"
        else
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Codex Desktop update staging · skipped (whitelist)"
        fi
        note_activity
        return 0
    fi

    if codex_desktop_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex Desktop update staging · skipped (Codex running)"
        note_activity
        return 0
    fi

    if codex_sparkle_updater_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex Desktop update staging · skipped (updater running)"
        note_activity
        return 0
    fi

    local open_file_state=0
    if codex_sparkle_staging_has_open_files "$staging_root"; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex Desktop update staging · skipped (files in use)"
        note_activity
        return 0
    else
        open_file_state=$?
    fi
    if [[ "$open_file_state" -eq 2 ]]; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex Desktop update staging · skipped (open-file check unavailable)"
        note_activity
        return 0
    fi

    local stale_entry
    while IFS= read -r -d '' stale_entry; do
        safe_clean "$stale_entry" "Codex Desktop stale update staging"
    done < <(command find -P "$staging_root" -mindepth 1 -maxdepth 1 -type d -mtime +"$MOLE_ORPHAN_AGE_DAYS" -print0 2> /dev/null)
}

# True when the Codex CLI or the Codex Desktop app is running.
codex_running() {
    command -v pgrep > /dev/null 2>&1 || return 1
    pgrep -x "codex" > /dev/null 2>&1 && return 0
    codex_desktop_running
}

antigravity_or_gemini_running() {
    command -v pgrep > /dev/null 2>&1 || return 1

    pgrep -x "Antigravity" > /dev/null 2>&1 && return 0
    pgrep -f "/Antigravity.app/" > /dev/null 2>&1 && return 0
    pgrep -x "gemini" > /dev/null 2>&1 && return 0
    pgrep -f "antigravity-browser-profile" > /dev/null 2>&1 && return 0
    return 1
}

chrome_devtools_mcp_running() {
    command -v pgrep > /dev/null 2>&1 || return 1

    pgrep -f "chrome-devtools-mcp" > /dev/null 2>&1 && return 0
    return 1
}

is_codex_runtime_active() {
    local runtime_dir="$1"
    [[ -d "$runtime_dir" ]] || return 1
    [[ -f "$runtime_dir/runtime.json" ]] || return 1
    [[ -d "$runtime_dir/dependencies/node" || -d "$runtime_dir/dependencies/python" ]] || return 1
    return 0
}

is_codex_runtime_stale() {
    local runtime_dir="$1"
    [[ -d "$runtime_dir" ]] || return 1

    local runtime_name
    runtime_name="$(basename "$runtime_dir")"
    case "$runtime_name" in
        tmp* | temp* | *.tmp | incomplete* | *.incomplete | *-incomplete | partial* | *.partial)
            return 0
            ;;
    esac

    if [[ ! -e "$runtime_dir/runtime.json" && ! -e "$runtime_dir/dependencies" ]]; then
        return 0
    fi

    return 1
}

_codex_runtime_size_human() {
    local target="$1"
    local size_kb=0

    if declare -f get_path_size_kb > /dev/null 2>&1; then
        size_kb=$(get_path_size_kb "$target" 2> /dev/null || echo 0)
    fi

    if declare -f bytes_to_human > /dev/null 2>&1; then
        bytes_to_human "$((size_kb * 1024))"
    else
        printf '%s KB' "$size_kb"
    fi
}

clean_codex_runtimes() {
    local runtime_root="$HOME/.cache/codex-runtimes"
    [[ -d "$runtime_root" ]] || return 0

    if declare -f is_path_whitelisted > /dev/null 2>&1 && is_path_whitelisted "$runtime_root"; then
        if [[ "${DRY_RUN:-false}" == "true" ]]; then
            echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Codex runtimes · would skip (whitelist)"
            note_activity
        else
            echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Codex runtimes · skipped (whitelist)"
        fi
        note_activity
        return 0
    fi

    if codex_desktop_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex runtimes · skipped (Codex running)"
        note_activity
        return 0
    fi

    local size_human
    size_human=$(_codex_runtime_size_human "$runtime_root")
    echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex runtimes · manual review (${size_human})"
    note_activity

    local runtime_dir
    while IFS= read -r -d '' runtime_dir; do
        if declare -f is_path_whitelisted > /dev/null 2>&1 && is_path_whitelisted "$runtime_dir"; then
            if [[ "${DRY_RUN:-false}" == "true" ]]; then
                echo -e "  ${YELLOW}${ICON_DRY_RUN}${NC} Codex runtimes · would skip (whitelist)"
                note_activity
            else
                echo -e "  ${GREEN}${ICON_SUCCESS}${NC} Codex runtimes · skipped (whitelist)"
            fi
            note_activity
            continue
        fi

        if is_codex_runtime_active "$runtime_dir"; then
            debug_log "Codex runtime left for manual review: $runtime_dir"
            continue
        fi

        if is_codex_runtime_stale "$runtime_dir"; then
            safe_clean "$runtime_dir" "Codex CLI runtimes"
        else
            debug_log "Codex runtime left for manual review: $runtime_dir"
        fi
    done < <(command find "$runtime_root" -mindepth 1 -maxdepth 1 -type d -print0 2> /dev/null)
}

# Codex CLI and Desktop share state under ~/.codex. Keep it out of default
# cleanup so app indexes, sessions, credentials, and local thread state survive.
clean_codex_cli() {
    local codex_root="$HOME/.codex"
    [[ -d "$codex_root" ]] || return 0

    if codex_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex CLI state · skipped (Codex running)"
        note_activity
        return 0
    fi

    echo -e "  ${GRAY}${ICON_WARNING}${NC} Codex CLI state · preserved (sessions, credentials)"
    note_activity
    debug_log "Codex CLI state left intact by default: $codex_root"
}

# Shared Chromium Default profile caches that are safe to regenerate.
clean_chromium_default_caches() {
    local profile_root="$1"
    local label="$2"

    [[ -d "$profile_root" ]] || return 0

    safe_clean "$profile_root/Default/Cache"/* "$label browser cache"
    safe_clean "$profile_root/Default/Code Cache"/* "$label code cache"
    safe_clean "$profile_root/Default/GPUCache"/* "$label GPU cache"
    safe_clean "$profile_root/Default/DawnGraphiteCache"/* "$label Dawn cache"
    safe_clean "$profile_root/Default/DawnWebGPUCache"/* "$label WebGPU cache"
}

# Antigravity (Gemini) keeps a full Chromium profile under
# ~/.gemini/antigravity-browser-profile. Clean its regenerable browser
# caches, mirroring the Antigravity Electron cache cleanup in clean_dev_misc.
clean_antigravity_caches() {
    local ag_profile="$HOME/.gemini/antigravity-browser-profile"

    if antigravity_or_gemini_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Antigravity/Gemini caches · skipped (Antigravity or Gemini running)"
        note_activity
        return 0
    fi

    if [[ -d "$ag_profile" ]]; then
        clean_chromium_default_caches "$ag_profile" "Antigravity"
        safe_clean "$ag_profile/GraphiteDawnCache"/* "Antigravity Graphite cache"
        safe_clean "$ag_profile/component_crx_cache"/* "Antigravity component cache"
        safe_clean "$ag_profile/extensions_crx_cache"/* "Antigravity extension cache"
        clean_service_worker_cache "Antigravity" "$ag_profile/Default/Service Worker/CacheStorage"
    fi
    # Never clean ~/.gemini/tmp: despite the name it stores gemini-cli
    # conversation checkpoints and prompt history (AI chat state, not temp).
}

clean_chrome_devtools_mcp_caches() {
    local mcp_profile="$HOME/.cache/chrome-devtools-mcp/chrome-profile"

    if chrome_devtools_mcp_running; then
        echo -e "  ${GRAY}${ICON_WARNING}${NC} Chrome DevTools MCP caches · skipped (server running)"
        note_activity
        return 0
    fi

    [[ -d "$mcp_profile" ]] || return 0

    clean_chromium_default_caches "$mcp_profile" "Chrome DevTools MCP"
    safe_clean "$mcp_profile/Default/DawnCache"/* "Chrome DevTools MCP Dawn cache"
    safe_clean "$mcp_profile/Default/GrShaderCache"/* "Chrome DevTools MCP shader cache"
    safe_clean "$mcp_profile/Default/GraphiteDawnCache"/* "Chrome DevTools MCP Graphite cache"
    safe_clean "$mcp_profile/GraphiteDawnCache"/* "Chrome DevTools MCP Graphite cache"
    safe_clean "$mcp_profile/component_crx_cache"/* "Chrome DevTools MCP component cache"
    safe_clean "$mcp_profile/extensions_crx_cache"/* "Chrome DevTools MCP extension cache"

    if declare -f clean_service_worker_cache > /dev/null 2>&1; then
        clean_service_worker_cache "Chrome DevTools MCP" "$mcp_profile/Default/Service Worker/CacheStorage"
    fi
}

# Misc dev tool caches.
clean_dev_misc() {
    safe_clean ~/Library/Caches/com.unity3d.*/* "Unity cache"
    safe_clean ~/Library/Caches/com.mongodb.compass/* "MongoDB Compass cache"
    safe_clean ~/Library/Caches/com.figma.Desktop/* "Figma cache"
    safe_clean ~/Library/Caches/com.github.GitHubDesktop/* "GitHub Desktop cache"
    safe_clean ~/Library/Caches/SentryCrash/* "Sentry crash reports"
    safe_clean ~/Library/Caches/KSCrash/* "KSCrash reports"
    safe_clean ~/Library/Caches/com.crashlytics.data/* "Crashlytics data"
    if [[ -d ~/Library/Application\ Support/Antigravity ]]; then
        safe_clean ~/Library/Application\ Support/Antigravity/Cache/* "Antigravity cache"
        safe_clean ~/Library/Application\ Support/Antigravity/Code\ Cache/* "Antigravity code cache"
        safe_clean ~/Library/Application\ Support/Antigravity/GPUCache/* "Antigravity GPU cache"
        safe_clean ~/Library/Application\ Support/Antigravity/DawnGraphiteCache/* "Antigravity Dawn cache"
        safe_clean ~/Library/Application\ Support/Antigravity/DawnWebGPUCache/* "Antigravity WebGPU cache"
    fi
    # Antigravity browser profile caches (~/.gemini)
    clean_antigravity_caches
    # Filo (Electron)
    if [[ -d ~/Library/Application\ Support/Filo ]]; then
        safe_clean ~/Library/Application\ Support/Filo/production/Cache/* "Filo cache"
        safe_clean ~/Library/Application\ Support/Filo/production/Code\ Cache/* "Filo code cache"
        safe_clean ~/Library/Application\ Support/Filo/production/GPUCache/* "Filo GPU cache"
        safe_clean ~/Library/Application\ Support/Filo/production/DawnGraphiteCache/* "Filo Dawn cache"
        safe_clean ~/Library/Application\ Support/Filo/production/DawnWebGPUCache/* "Filo WebGPU cache"
    fi
    # Claude (Electron)
    if [[ -d ~/Library/Application\ Support/Claude ]]; then
        safe_clean ~/Library/Application\ Support/Claude/Cache/* "Claude cache"
        safe_clean ~/Library/Application\ Support/Claude/Code\ Cache/* "Claude code cache"
        safe_clean ~/Library/Application\ Support/Claude/GPUCache/* "Claude GPU cache"
        safe_clean ~/Library/Application\ Support/Claude/DawnGraphiteCache/* "Claude Dawn cache"
        safe_clean ~/Library/Application\ Support/Claude/DawnWebGPUCache/* "Claude WebGPU cache"
        safe_clean ~/Library/Application\ Support/Claude/sentry/* "Claude sentry cache"
        safe_clean ~/Library/Application\ Support/Claude/pending-uploads/* "Claude pending uploads"
    fi
    # Qoder (VS Code fork, Electron)
    if [[ -d ~/Library/Application\ Support/Qoder ]]; then
        safe_clean ~/Library/Application\ Support/Qoder/Cache/* "Qoder cache"
        safe_clean ~/Library/Application\ Support/Qoder/CachedData/* "Qoder cached data"
        safe_clean ~/Library/Application\ Support/Qoder/CachedExtensionVSIXs/* "Qoder extension cache"
        safe_clean ~/Library/Application\ Support/Qoder/Code\ Cache/* "Qoder code cache"
        safe_clean ~/Library/Application\ Support/Qoder/GPUCache/* "Qoder GPU cache"
        safe_clean ~/Library/Application\ Support/Qoder/DawnGraphiteCache/* "Qoder Dawn cache"
        safe_clean ~/Library/Application\ Support/Qoder/DawnWebGPUCache/* "Qoder WebGPU cache"
        safe_clean ~/Library/Application\ Support/Qoder/logs/* "Qoder logs"
    fi
    # Prisma ORM engine binaries cache
    safe_clean ~/.cache/prisma/* "Prisma cache"
    # OpenCode AI tool cache
    safe_clean ~/.cache/opencode/* "OpenCode cache"
    # OpenCode CLI session state (~/.cache side above covers Electron cache)
    if [[ -d ~/.local/share/opencode ]]; then
        safe_clean ~/.local/share/opencode/snapshot/* "OpenCode snapshots"
        safe_clean ~/.local/share/opencode/log/* "OpenCode logs"
    fi
    # Codex Desktop runtimes contain active Node/Python dependencies.
    clean_codex_runtimes
    # Sparkle uses random first-level directories for each update installation.
    clean_codex_desktop_staging
    # Codex CLI working-directory caches (~/.codex)
    clean_codex_cli
    # Cursor Agent session logs (versions cleaned separately in clean_dev_ai_agents)
    [[ -d "$HOME/.local/share/cursor-agent" ]] && safe_find_delete "$HOME/.local/share/cursor-agent" "*.log" "$MOLE_LOG_AGE_DAYS" "f"
    # Playwright cached browser binaries
    safe_clean ~/Library/Caches/ms-playwright/* "Playwright browsers"
    # Chrome DevTools MCP keeps a Chromium profile; clean only rebuildable caches.
    clean_chrome_devtools_mcp_caches
    # Claude Code state under ~/.claude can include persistent memory,
    # plugin registry data, hooks, and session context. Do not clean it
    # automatically; users can remove specific paths manually if needed.
    # Wondershare orphan installer payload (bundle ID differs from live app)
    safe_clean ~/Library/Application\ Support/com.wondershare.Installer/* "Wondershare installer payload"
}
# Shell and VCS leftovers.
clean_dev_shell() {
    safe_clean ~/.gitconfig.lock "Git config lock"
    safe_clean ~/.gitconfig.bak* "Git config backup"
    safe_clean ~/.oh-my-zsh/cache/* "Oh My Zsh cache"
    safe_clean ~/.config/fish/fish_history.bak* "Fish shell backup"
    safe_clean ~/.bash_history.bak* "Bash history backup"
    safe_clean ~/.zsh_history.bak* "Zsh history backup"
    safe_clean ~/.cache/pre-commit/* "pre-commit cache"
}
# Network tool caches.
clean_dev_network() {
    safe_clean ~/.cache/curl/* "curl cache"
    safe_clean ~/.cache/wget/* "wget cache"
    safe_clean ~/Library/Caches/curl/* "macOS curl cache"
    safe_clean ~/Library/Caches/wget/* "macOS wget cache"
}
# Elixir/Erlang ecosystem.
# Note: ~/.mix/archives contains installed Mix tools - excluded from cleanup
clean_dev_elixir() {
    safe_clean ~/.hex/cache/* "Hex cache"
}
# Haskell ecosystem.
# Note: ~/.stack/programs contains Stack-installed GHC compilers - excluded from cleanup
clean_dev_haskell() {
    safe_clean ~/.cabal/packages/* "Cabal install cache"
}
# OCaml ecosystem.
clean_dev_ocaml() {
    safe_clean ~/.opam/download-cache/* "Opam cache"
}
# Main developer tools cleanup sequence.
clean_developer_tools() {
    stop_section_spinner

    # CLI tools and languages
    clean_dev_npm
    clean_dev_python
    clean_dev_go
    clean_dev_mise
    clean_dev_rust
    check_rust_toolchains
    clean_dev_ruby
    clean_dev_perl
    clean_dev_docker
    clean_dev_cloud
    clean_dev_nix
    clean_dev_shell
    clean_dev_frontend
    clean_project_caches
    clean_dev_mobile
    clean_dev_jvm
    clean_dev_jetbrains_toolbox
    clean_dev_jetbrains_logs
    clean_dev_ai_agents
    clean_dev_other_langs
    clean_dev_cicd
    clean_dev_database
    clean_dev_api_tools
    clean_dev_network
    clean_dev_misc
    clean_dev_elixir
    clean_dev_haskell
    clean_dev_ocaml

    # GUI developer applications
    clean_xcode_tools
    clean_code_editors

    # Homebrew: only blanket-clean downloads/. Wiping api/ (JSON that needs a
    # network re-download) and bootsnap/ (recompiled Ruby) leaves brew silent
    # for ~94s before its first output on the next run.
    safe_clean ~/Library/Caches/Homebrew/downloads/* "Homebrew cache"
    local brew_lock_dirs=(
        "/opt/homebrew/var/homebrew/locks"
        "/usr/local/var/homebrew/locks"
    )
    for lock_dir in "${brew_lock_dirs[@]}"; do
        if [[ -d "$lock_dir" && -w "$lock_dir" ]]; then
            safe_clean "$lock_dir"/* "Homebrew lock files"
        elif [[ -d "$lock_dir" ]]; then
            if find "$lock_dir" -mindepth 1 -maxdepth 1 -print -quit 2> /dev/null | grep -q .; then
                debug_log "Skipping read-only Homebrew locks in $lock_dir"
            fi
        fi
    done
    clean_homebrew
}
